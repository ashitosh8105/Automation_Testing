package WebDriverMethod;

import org.openqa.selenium.chrome.ChromeDriver;

public class NavigateAmazon {

	public static void main(String[] args) throws InterruptedException 
	{
		
		
		ChromeDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		
		Thread.sleep(2000);
		driver.get("https://demowebshop.tricentis.com/");
		Thread.sleep(2000);
		
		driver.navigate().to("https://www.myntra.com/");
		Thread.sleep(2000);
		
		driver.navigate().back();
		Thread.sleep(2000);
		
		driver.navigate().refresh();
		Thread.sleep(2000);
		 
		
		driver.navigate().forward();
		Thread.sleep(2000);
		
		
		
//		driver.close();
		
		
		
		

	}

}
