package WebDriverMethod;

import java.util.List;
import java.util.Set;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class MultipleElementsAssign {
       
	private static final String BY = null;
     
	public static void main(String[] args) throws InterruptedException {
		
	    String expected_url="https://demowebshop.tricentis.com/";
		ChromeDriver driver=new ChromeDriver();
         
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		driver.get("https://demowebshop.tricentis.com/");
		Actions act=new Actions(driver);
		act.keyDown(Keys.PAGE_DOWN).perform();
		
		String actual_url=driver.getCurrentUrl();
		if(actual_url.equals(expected_url)) {
			System.out.println("Page verified successfully");
			
		//using this path only three link are opened //fb,twitter,RSS remaining pages are not opened
			
//			List<WebElement> follow_us = driver.findElements(By.xpath("//div[@class='column follow-us']//ul//li/a"));
			
			List<WebElement> follow_us = driver.findElements(By.xpath("//a[@target='_blank']"));
			
			for(WebElement web : follow_us){
				
				web.click();
				Thread.sleep(2000);
			}
		}
		else 
		{
		  System.out.println("Page is not verified");
		}
		
		Thread.sleep(2000);
		driver.close();
		
	}

}
