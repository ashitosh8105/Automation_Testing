package WebDriverMethod;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class MultileElements 
{
		public static void main(String[] args) throws InterruptedException {
	
		ChromeDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.get("https://demowebshop.tricentis.com/");
		
		
	
//       List<WebElement>comunity_poll= driver.findElements(By.xpath("//input[@type='radio']"));
		
		List<WebElement> comunity_poll = driver.findElements(By.xpath("//ul[@class='poll-options']/li/input"));
        for(WebElement web : comunity_poll) 
        {
        	
			web.click();
			Thread.sleep(2000);
		}
		Thread.sleep(2000);
		driver.close();

	}

}
