package WebDriverMethod;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class QuitMethod {

	public static void main(String[] args) throws InterruptedException {
	
		//open browser
		ChromeDriver driver=new ChromeDriver();
		
		//maximize the browser
		driver.manage().window().maximize();
		Thread.sleep(3000);
		
		//get page 
		driver.get("https://demowebshop.tricentis.com/");
		
		Thread.sleep(3000);
		driver.findElement(By.linkText("Facebook")).click();
		
		Thread.sleep(3000);
		driver.quit();//This method close the Parent as well as child page
		
		
		
		
		
		

	}

}
