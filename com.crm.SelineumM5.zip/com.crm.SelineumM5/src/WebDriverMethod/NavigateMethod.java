package WebDriverMethod;

import org.openqa.selenium.chrome.ChromeDriver;

public class NavigateMethod {
   public static void main(String[] args) throws InterruptedException {
	   
       //open the browser
	   ChromeDriver driver=new ChromeDriver();
	   
	   //maximize the browser
	   driver.manage().window().maximize();
	   
	   //waiting time
	   Thread.sleep(2000);
	   driver.get("https://demowebshop.tricentis.com/");
	   Thread.sleep(2000);
	   
	   //navigate flipcart
	   driver.navigate().to("https://www.flipkart.com/");
	   Thread.sleep(2000);
	   
	   //back to the DWS page
	   driver.navigate().back();
	   Thread.sleep(2000);
	   
	   //refresh page
	   driver.navigate().refresh();
	   Thread.sleep(2000);
	   
	   //go to the flipcart
	   driver.navigate().forward();
	   Thread.sleep(2000);
//	 close the browser
//	   driver.close();
	   
	
}
}
