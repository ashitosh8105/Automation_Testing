package com.screenshot;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.time.LocalDateTime;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;

public class Assighnment{
       
	public static void main(String[] args) throws IOException {
		
//getting a current date and time of system
		LocalDateTime date=LocalDateTime.now();
		String name=date.toString().replace(':','-');
		
		ChromeDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		
		//implicit waiting time
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		
		driver.get("https://demowebshop.tricentis.com/");
		
		driver.findElement(By.className("ico-login")).click();
		
		WebElement email = driver.findElement(By.id("Email"));
		email.sendKeys("sbdaxahlksdjhk@gmail.com");
		
		WebElement pass = driver.findElement(By.id("Password"));
		pass.sendKeys("P@ss1234");
		
		driver.findElement(By.id("RememberMe")).click();
		
		WebElement login_page = driver.findElement(By.className("returning-wrapper"));
		File from=login_page.getScreenshotAs(OutputType.FILE);
		
		//saving the screenshot into the file
		File to=new File("C:\\Screenshot\\login"+name+".png");
		FileHandler.copy(from, to);
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		driver.close();
		
       
	}

}
