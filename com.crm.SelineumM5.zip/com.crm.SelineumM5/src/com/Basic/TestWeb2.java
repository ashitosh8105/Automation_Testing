package com.Basic;

import org.openqa.selenium.chrome.ChromeDriver;

public class TestWeb2 {
	
	private void maian() {
		// TODO Auto-generated method stub

		ChromeDriver driver=new ChromeDriver();
	
	     driver.manage().window().maximize();
	     
	     driver.get("https://www.bmw.in/en/index.html");
	     driver.close();  
	     
	}
}
