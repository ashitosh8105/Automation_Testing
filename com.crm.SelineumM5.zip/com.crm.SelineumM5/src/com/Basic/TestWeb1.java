package com.Basic;

import org.openqa.selenium.chrome.ChromeDriver;

public class TestWeb1 {

	public static void main(String[] args) {
		
		ChromeDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		
		driver.get("https://www.google.com/search?q=myntra.com&rlz=1C1CHZN_enIN991IN991&oq=myn&gs_lcrp=EgZjaHJvbWUqBggBEEUYOzIGCAAQRRg8MgYIARBFGDsyBggCEEUYOTIOCAMQRRgnGDsYgAQYigUyDAgEEEUYOxixAxiABDIGCAUQRRg8MgYIBhBFGDwyBggHEEUYQdIBCDI0MDhqMGo3qAIIsAIB&sourceid=chrome&ie=UTF-8");
		
		driver.close();
	}

}
