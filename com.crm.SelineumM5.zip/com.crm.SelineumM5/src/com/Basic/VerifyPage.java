package com.Basic;

import org.openqa.selenium.chrome.ChromeDriver;
//verify page using url
public class VerifyPage {
   public static void main(String[] args) throws InterruptedException {
	   
	   String expected_URL="https://demowebshop.tricentis.com/";
	   ChromeDriver driver=new ChromeDriver();
	   //open chrome browser
	   driver.manage().window().maximize();
	   
	   //waiting condition
	   Thread.sleep(2000);
	   //maximize the browser
	   driver.get("https://demowebshop.tricentis.com/");
	   
	   //get current url
	   String actual_url=driver.getCurrentUrl();
	   
	   //verify the page
	   if(actual_url.equals(expected_URL)){
		   System.out.println("Im a dws page");
	   }
	   else {
		   System.out.println("I am not dws page");
	   }
	   Thread.sleep(2000);
	   driver.close();	
   }
}
