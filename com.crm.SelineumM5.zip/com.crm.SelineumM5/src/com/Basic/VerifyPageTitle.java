package com.Basic;

import org.openqa.selenium.chrome.ChromeDriver;

public class VerifyPageTitle {
//verify page usign tile
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		   String expected_title="Demo Web Shop";
		   
		   //open the chrome browser
		   ChromeDriver driver=new ChromeDriver();
		  
		   
		   //maximize the browser
		   driver.manage().window().maximize();
		   
		   //waiting condition
		   Thread.sleep(2000);
		   
		   driver.get("https://demowebshop.tricentis.com/");
		   
		   //get title of the page
		   String actual_title=driver.getTitle();
		   
		   //verify the page using title
		   if(actual_title.equals(expected_title))//compareing the actual title and expected title 
		   {
			   System.out.println("Im a dws page");
		   }
		   else {
			   System.out.println("I am not in dws page");
		   }
		   Thread.sleep(2000);
		   driver.close();	
	   }
	}


