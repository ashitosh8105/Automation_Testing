package com.Basic;

import org.openqa.selenium.chrome.ChromeDriver;

public class VerifyRBTitle 
{
  public static void main(String[] args) throws InterruptedException 
  {
	  //store the expected data
    String expected_title="Agents - EaseMyTrip";
    //open the chrome browser
    ChromeDriver driver=new ChromeDriver();
    
    //maximixe the chrome browser
    driver.manage().window().maximize();
    
    Thread.sleep(2000);
    //get url
    driver.get("https://www.easemytrip.com/agents");
    
    //get actual title
    String actual_title=driver.getTitle();
    
    //verify the page using title
    if(actual_title.equals(expected_title))
    {
    	System.out.println("Page verify successfully");
    }
    else {
    	System.out.println("Page not verified");
    }
    
    Thread.sleep(2000);
    driver.close();
    
}
}
