package com.Basic;

import org.openqa.selenium.chrome.ChromeDriver;
//verifiying page using url
public class VerifyRedBusPage {
          public static void main(String[] args) throws InterruptedException {
			
        	  String expected_url="https://www.redbus.in/help/login";
        	  //open the chrome browser
        	  ChromeDriver driver=new ChromeDriver();
        	 //maximize the browser
        	  driver.manage().window().maximize();
        	  
        	  Thread.sleep(2000);
        	  //get current url
        	  driver.get("https://www.redbus.in/help/login");
        	  
        	  //verify the page
        	  String actual_url=driver.getCurrentUrl();
        	  
        	  if(actual_url.equals(expected_url)) {
        		  System.out.println("Page verified");
        		  
        	  }
        	  else {
        		  System.out.println("Page not verified");
        	  }
        	  
        	  //waiting time
        	  Thread.sleep(2000);
        	  //close the chrome browser
        	  driver.close();        	  
		}
}
