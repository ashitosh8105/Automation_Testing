package com.Synchronization;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
public class Explicit_wait {
	
		public static void main(String[] args) {
		
			//Open The browser
			ChromeDriver driver=new ChromeDriver();
			//maximize the browser
			driver.manage().window().maximize();
			//enter into web page
			driver.get("https://www.shoppersstack.com/");
			
			WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(30));
			WebElement login=wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//button[@id='loginBtn']"))));
			login.click();
			
			//Check based on the visibile::-If it is visible it will click 
			WebElement create_account=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Create Account']")));
			create_account.click();
			
			
			
			
			

	}
}
