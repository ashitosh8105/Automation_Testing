package com.Synchronization;

import org.bouncycastle.oer.its.ieee1609dot2.basetypes.Duration;
import org.openqa.selenium.chrome.ChromeDriver;

public class OmayoBlogSpot{

	public static void main(String[] args) {


		ChromeDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		//implicit wait
		
//		driver.manage().timeouts().implicitlyWait(Duration.ofseconds(15));
		
		driver.get("https://omayo.blogspot.com/");
		
//		ChromeDriverWait wait=new ChromeDriverWait(driver,Duration.milliseconds(30));
		

	}

}
