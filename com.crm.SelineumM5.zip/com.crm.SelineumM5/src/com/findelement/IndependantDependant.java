package com.findelement;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class IndependantDependant {

	public static void main(String[] args) throws InterruptedException {
		
		ChromeDriver driver=new ChromeDriver();

		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		driver.get("https://demowebshop.tricentis.com/digital-downloads");
		//finding the element using dependant and independant xpath
//		steps:
//		   1)find independant element
//		   2)traverset to the dependant element
		     
//		sibling Treversing
//		   downword->following-sibling::tag_name
//		   upword -> preceding-sibling::tag_name
//		   parent-> traversing: /..
//		   child -> trversing:/tagname

		WebElement album3rd = driver.findElement(By.xpath("//a[text()='3rd Album']/..//following-sibling::div[3]/div/span"));
		 
		System.out.println(album3rd.getText());
		Thread.sleep(2000);
		driver.close();
	
	}

}
