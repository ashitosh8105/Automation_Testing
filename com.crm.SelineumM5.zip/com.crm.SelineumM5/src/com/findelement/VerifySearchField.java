package com.findelement;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class VerifySearchField {

	public static void main(String[] args) throws InterruptedException {
		String expected_url="https://www.myntra.com/";
		//open the chrome browser
		ChromeDriver driver=new ChromeDriver();
		//maximize the chrome browser
		
		driver.manage().window().maximize();
		
		//waiting time
		Thread.sleep(3000);
		//get url
		driver.get("https://www.myntra.com/");
		//get actual url
		
		String actual_url=driver.getCurrentUrl();
		
		//verify the page
		if(actual_url.equals(expected_url)) {
			System.out.println("Page successfully verified");
			
			WebElement search_field = driver.findElement(By.tagName("input"));
			search_field.sendKeys("shirt");
		}
		else {
			System.out.println("Page not found");
		}
		Thread.sleep(3000);
		//close the chrome driver
		driver.close();
	}
}
