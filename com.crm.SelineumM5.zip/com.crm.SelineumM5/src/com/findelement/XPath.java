package com.findelement;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class XPath {

	public static void main(String[] args) throws InterruptedException {
		

	ChromeDriver driver=new ChromeDriver();
	
	  driver.manage().window().maximize();
	  Thread.sleep(2000);
	  
	  driver.get("https://demowebshop.tricentis.com/");
	  //finding the element using xpath locator. 
	  driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).click();
	  
	  WebElement search = driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[3]/form/input[1]"));
	   search.sendKeys("OnePlus");
	   
	   driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[3]/form/input[2]")).click();
	   
	  
	  
	  Thread.sleep(2000);
	  driver.close();
	  
	  
}
}
