package com.findelement;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestAssign2 {

	public static void main(String[] args) throws InterruptedException 
	{
		//store expected title 
		String expected_title="Demo Web Shop";
		
		//open the chrome browser
		ChromeDriver driver=new ChromeDriver();
		
		//maximize the window
		driver.manage().window().maximize();
		
		//waiting time
		Thread.sleep(2000);
		
		//get url
		
		driver.get("https://demowebshop.tricentis.com/");
		
		//get title and store actual title
		
		String actual_title=driver.getTitle();
		
		if(actual_title.equals(expected_title)) 
		{
			System.out.println("Page verified succesfully");
			driver.findElement(By.className("ico-login")).click();
			
			WebElement email1 = driver.findElement(By.className("email"));
			email1.sendKeys("ashitosh12345@gmail.com");
			
			WebElement pass1 = driver.findElement(By.id("Password"));
			pass1.sendKeys("P@ss1234");
			
			driver.findElement(By.cssSelector("input[id='RememberMe']")).click();
			
			driver.findElement(By.cssSelector("input[value='Log in']")).click();
			
		}
		else {
			System.out.println("Page not verified");
			
			
		}
		
		
		Thread.sleep(2000);
//		driver.close();
		
		

	}

}
