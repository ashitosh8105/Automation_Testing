package com.findelement;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AbsoluteXpathAssign {

	public static void main(String[] args) throws InterruptedException {
	
		String expected_url="https://demowebshop.tricentis.com/";
		 ChromeDriver driver=new ChromeDriver();
		 
		 driver.manage().window().maximize();
		 
		 Thread.sleep(2000);
		 driver.get("https://demowebshop.tricentis.com/");
		 
		 String actual_url=driver.getCurrentUrl();
		 if(actual_url.equals(expected_url)) 
		 {
			System.out.println("Page Verified Successfully"); 
			
			//find element of register
			driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).click();
			
			driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/form/div/div[2]/div[2]/div[2]/div[1]/div[1]/input")).click();
			
		  WebElement first_name = driver.findElement(By.xpath("html/body/div[4]/div[1]/div[4]/div[2]/form/div/div[2]/div[2]/div[2]/div[2]/input"));
		    first_name.sendKeys("ashitosh");
		    
		  WebElement last_name = driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/form/div/div[2]/div[2]/div[2]/div[3]/input"));
		     last_name.sendKeys("jagtap"); 

		     
	      WebElement email = driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/form/div/div[2]/div[2]/div[2]/div[4]/input"));
	          email.sendKeys("qspider3214@gmail.com");
	          
	        WebElement pass = driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/form/div/div[2]/div[3]/div[2]/div[1]/input"));
		     pass.sendKeys("Demo@123");
		     
		     WebElement confirm_pass = driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/form/div/div[2]/div[3]/div[2]/div[2]/input"));
		     confirm_pass.sendKeys("Demo@123");
		     
		     driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/form/div/div[2]/div[4]/input")).click();
		     
		     System.out.println("Registration successfully done");
		     
						
		 }
		 else {
			 System.out.println("Page doesnt verified");
		 }
		 
		 
		 Thread.sleep(2000);
		 driver.close();
		 

	}

}
