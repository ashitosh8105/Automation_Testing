package com.findelement;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestAssign1 
{

	public static void main(String[] args) throws InterruptedException {
		
		String expected_url="https://demowebshop.tricentis.com/";
		//opening browser
		ChromeDriver driver=new ChromeDriver();
		
		//maximize the chrome browser
		
		driver.manage().window().maximize();
		//waiting time
		Thread.sleep(3000);
		
		//geting the site url
		driver.get("https://demowebshop.tricentis.com/");
		
		String actual_url=driver.getCurrentUrl();
		
		
		//verifying the page
		
		if(actual_url.equals(expected_url))
		{
			System.out.println("Page verified succesfully");
			
			//verifying the Register button
			driver.findElement(By.cssSelector("a[class='ico-register']")).click();
			
			//verifying the check box
			driver.findElement(By.cssSelector("label[class='forcheckbox']")).click();
			
			//verifying the input fields and filling the data 
			WebElement first_name = driver.findElement(By.cssSelector("input[id='FirstName']"));
			first_name.sendKeys("Ashitosh");
			 
			WebElement last_name = driver.findElement(By.cssSelector("input[id='LastName']"));
			last_name.sendKeys("Jagtap");
			
			WebElement email = driver.findElement(By.cssSelector("input[id='Email']"));
			email.sendKeys("ashitosh123456@gmail.com");
			
			WebElement password = driver.findElement(By.cssSelector("input[id='Password']"));
			password.sendKeys("P@ss1234");
			
			WebElement confirmpass = driver.findElement(By.cssSelector("input[id='ConfirmPassword']"));
			confirmpass.sendKeys("P@ss1234");
			
			//checking the register button
			driver.findElement(By.cssSelector("input[id='register-button']")).click();
			
	}
		else {
			System.out.println("Page not verified");
		}
		
		Thread.sleep(3000);
//		driver.close();
		

	}

}
