package com.findelement;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class RelativeXpath {

	public static void main(String[] args) throws InterruptedException {

		ChromeDriver driver=new ChromeDriver();
		
		  driver.manage().window().maximize();
		  Thread.sleep(2000);
		  

		  driver.get("https://demowebshop.tricentis.com/");
		  Thread.sleep(2000);
		  
//		  Relatives Xpath
//		  1)xpath by attribute
//		    syntax: //Tag_Name[@Attribute_Name='Attribute_name']
		  
		  driver.findElement(By.xpath("//a[@class='ico-register']")).click();
		  Thread.sleep(2000);
		  driver.navigate().back();
		  
//		  2)xpath  by text function (always not recomended to use this function)
//		  Note:linkText/partial text only works on anchor<a> tag
		  
//		    syntax: //Tag_Name[text()='value']
		  
		  WebElement poll = driver.findElement(By.xpath("//strong[text()='Community poll']"));
		   System.out.println(poll.getText());
		   Thread.sleep(2000);
		   
		   
//		   driver.findElement(By.xpath("//a[text()='Digital downloads']")).click();//NoSuchElementException
		   
//		   3)xpath by contains function
//		     syntax://Tag_name[contain(text(),'value')]
		   
		   driver.findElement(By.xpath("//a[contains(text(),'Digital downloads')]")).click();
		   
		   driver.navigate().back();
		   Thread.sleep(2000);
		   
		   
//		   4)xpath by group by index
//		   syntax:(//tag_name[@AN='AV'])[index value]
		   
		   WebElement text = driver.findElement(By.xpath("(//input[@type='text'])[2]"));
		   text.sendKeys("Ashitosh");
		   
//		   5)independant/dependent xpath
//		      steps: find independant element
//		              traverse to the dependant
		   
		   
		     
		           
		   
		   
		 
		  
		  Thread.sleep(2000);
		  driver.close();		  

	}

}
