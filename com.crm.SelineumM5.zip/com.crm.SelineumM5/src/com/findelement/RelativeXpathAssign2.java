package com.findelement;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class RelativeXpathAssign2 
{

	public static void main(String[] args) throws InterruptedException {
		
		String expected_title="Demo Web Shop";

		ChromeDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		
		Thread.sleep(2000);
		driver.get("https://demowebshop.tricentis.com/");
		
		
		String actual_title=driver.getTitle();
		
		if(actual_title.equals(expected_title)){
			
	     System.out.println("Page verified successgully");
		
		//login page verified using relative path
		//using xpath by attribute
		driver.findElement(By.xpath("//a[@class='ico-login']")).click();
		
		//using enter login username creadition using xpath by attribute function
     	driver.findElement(By.xpath("//input[@class='email']")).sendKeys("qspider3214@gmail.com");
//		
		driver.findElement(By.xpath("//input[@id='Password']")).sendKeys("Demo@123");
		
		driver.findElement(By.xpath("//input[@id='RememberMe']")).click();
		
		driver.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
//		
	  }
	 else {
			System.out.println("Page is not found");
		}
//		
		
		
		
		Thread.sleep(2000);
		driver.close();
		
		
		
	}

}
