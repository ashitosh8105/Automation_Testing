package com.findelement;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Locator 
{
  public static void main(String[] args) throws InterruptedException 
  {    
	  String expected_url="https://demowebshop.tricentis.com/";
	  ChromeDriver driver=new ChromeDriver();
	  
	  driver.manage().window().maximize();
	  Thread.sleep(2000);
	  driver.get("https://demowebshop.tricentis.com/");
	  
	  String actual_url=driver.getCurrentUrl();
	  if(actual_url.equals(expected_url)) {
		  System.out.println("im in dws page");
			//find element using tag name and perform action.
		  WebElement search_field = driver.findElement(By.tagName("input"));
		  search_field.sendKeys("ashitosh");
		
		  driver.findElement(By.linkText("Log in")).click();
		  
	  }
	  else {
		  System.out.println("im not dws page");
	  }
	  
	  Thread.sleep(2000);
	  
//	  driver.close();	  
	  
	
}
}
