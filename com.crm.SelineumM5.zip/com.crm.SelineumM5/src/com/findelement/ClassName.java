package com.findelement;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class ClassName {

	public static void main(String[] args) throws InterruptedException {
		// open browser
		ChromeDriver driver=new ChromeDriver();
		
		//maximize the chrome
		
		driver.manage().window().maximize();
		//waiting time
		Thread.sleep(2000);
		//get url
		driver.get("https://demowebshop.tricentis.com/");
		  //use class name
//		  driver.findElement(By.className("button-1")).click();
		
		//find element using class name and perform action using click()method.
//		driver.findElement(By.className("ico-register")).click();
		
		//tag name
//		driver.findElement(By.id("small-searchterms")).click();
		
		  //use name
//		  driver.findElement(By.name("q")).click();
		
		//use linkText
//		 driver.findElement(By.linkText("Log in")).click();
		
		//use partial text
//	     driver.findElement(By.partialLinkText("Shopping")).click();
		 Thread.sleep(2000);
		  
		 //using css selector
		 //syntax:TagName[Attribute Name:"value"];
		 
//		 driver.findElement(By.cssSelector())
		 
		 
		
//		driver.close();
		
		
	}

}
