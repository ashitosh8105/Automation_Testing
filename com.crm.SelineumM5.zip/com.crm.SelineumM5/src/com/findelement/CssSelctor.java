package com.findelement;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CssSelctor {

	public static void main(String[] args) throws InterruptedException {
	
		ChromeDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		
		Thread.sleep(2000);
		
		driver.get("https://demowebshop.tricentis.com/");
		  WebElement search_field = driver.findElement(By.tagName("input"));
		  search_field.sendKeys("iphone16");
		  
		  //we find the element using cssSelector and perforom the action
		
//		driver.findElement(By.cssSelector("input[value='Search']")).click();
		
		//get the text
		
//		WebElement register = driver.findElement(By.linkText("Register"));
//		System.out.println(register.getText());//Register
		
		
		WebElement poll = driver.findElement(By.linkText("Community poll"));
		System.out.println(poll.getText());//throws NoSuchElementException
		
		
		Thread.sleep(2000);
		
//		driver.close();
		
	}

}
