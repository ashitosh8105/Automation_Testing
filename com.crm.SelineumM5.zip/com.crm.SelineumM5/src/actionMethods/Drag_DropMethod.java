package actionMethods;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Drag_DropMethod {

	public static void main(String[] args) throws InterruptedException
	{
		
		
		ChromeDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		driver.get("http://www.dhtmlgoodies.com/scripts/drag-drop-custom/demo-drag-drop-3.html");
		Thread.sleep(2000);
		
		Actions act = new Actions(driver);
		
		WebElement source = driver.findElement(By.id("box6"));
		WebElement target = driver.findElement(By.id("box106"));
		//dragAnddrop()
//		act.dragAndDrop(source, target).perform();
		
		//clickAndHold() method
		act.clickAndHold(source).perform();
		act.release(target).perform();
		
		Thread.sleep(2000);
		
		WebElement source1 = driver.findElement(By.id("box7"));
		WebElement target1 = driver.findElement(By.id("box107"));
		
 //DragAndDrop
		
//		act.dragAndDrop(source1, target1).perform();
		
		//clickAndHold() method
		act.clickAndHold(source1).perform();
		act.release(target1).perform();
		
		Thread.sleep(2000);
		WebElement source2 = driver.findElement(By.id("box1"));
		WebElement target2 = driver.findElement(By.id("box101"));
		   
	    act.clickAndHold(source2).perform();
	    act.release(target2).perform();

	    Thread.sleep(2000);
		
		WebElement source3 = driver.findElement(By.id("box4"));
		WebElement target3 = driver.findElement(By.id("box104"));
		   
	    act.clickAndHold(source3).perform();
	    act.release(target3).perform();
            
		Thread.sleep(2000);
		
		WebElement source4 = driver.findElement(By.id("box5"));
		WebElement target4 = driver.findElement(By.id("box105"));
		   
	    act.clickAndHold(source4).perform();
	    act.release(target4).perform();
	    
	    Thread.sleep(2000);

		WebElement source5 = driver.findElement(By.id("box2"));
		WebElement target5 = driver.findElement(By.id("box102"));
		   
	    act.clickAndHold(source5).perform();
	    act.release(target5).perform();
	    
	    Thread.sleep(2000);
	    WebElement source6 = driver.findElement(By.id("box3"));
		WebElement target6 = driver.findElement(By.id("box103"));
		   
	    act.clickAndHold(source6).perform();
	    act.release(target6).perform();
		Thread.sleep(2000);
		driver.close();

	}

}
