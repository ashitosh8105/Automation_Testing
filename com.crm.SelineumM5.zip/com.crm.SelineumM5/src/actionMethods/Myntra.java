package actionMethods;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Myntra {

	public static void main(String[] args) throws InterruptedException {
		  
       ChromeDriver driver=new ChromeDriver();
       
       driver.manage().window().maximize();
       Thread.sleep(2000);
       
       driver.get("https://www.myntra.com/");
       Thread.sleep(2000);
       
//       driver.findElement(By.linkText("Men")).click();
       //creating the object of Action
       Actions act=new Actions(driver);
       
       WebElement men = driver.findElement(By.xpath("//a[@data-group='men']"));
       act.moveToElement(men).perform();//moving to the perticular element if we want
       //frze the page and move to option click ctrl+\
       driver.findElement(By.xpath("//a[text()='Jackets']")).click();
       
       Thread.sleep(3000);
//       driver.close();
       
       
	}

}
