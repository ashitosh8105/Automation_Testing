package actionMethods;

import org.openqa.selenium.Keys;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SendKeyToSearchField {

	public static void main(String[] args) throws InterruptedException 
	{
		
		ChromeDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		driver.get("https://demowebshop.tricentis.com/");
		
		
		Actions act=new Actions(driver);
		Thread.sleep(2000);
		
		act.keyDown(Keys.TAB)
		.keyDown(Keys.TAB)
		.keyDown(Keys.TAB)
		.keyDown(Keys.TAB)
	    .keyDown(Keys.TAB)
		.keyDown(Keys.TAB).perform();
		act.sendKeys("oneplus").keyDown(Keys.ENTER).perform();
		
		driver.close();
		

	}

}
