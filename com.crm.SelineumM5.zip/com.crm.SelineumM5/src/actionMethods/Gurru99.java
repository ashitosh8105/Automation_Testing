package actionMethods;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Gurru99 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		 ChromeDriver driver=new ChromeDriver();
	       
	       driver.manage().window().maximize();
	       Thread.sleep(2000);
	       
	       driver.get("https://demo.guru99.com/test/simple_context_menu.html");
	       
	       //creating object of Action class
	       Actions act=new Actions(driver);
	       Thread.sleep(2000);
	       //finding the element
	       WebElement right_click = driver.findElement(By.xpath("//span[text()='right click me']"));
	       WebElement paste = driver.findElement(By.xpath("//span[text()='Paste']"));
	       act.doubleClick(right_click);//catch block get excuted
//	       act.contextClick(right_click).click(paste).perform();//try block get excuted
	       try{
	    	   right_click.click();	
	    	   System.out.println("Alert popUp is not displayed........");
	    	   
	       }catch(Exception e){
	    	   System.out.println("Alert popUp is Displayed.......");
	       }
	      driver.close();
	}

}
