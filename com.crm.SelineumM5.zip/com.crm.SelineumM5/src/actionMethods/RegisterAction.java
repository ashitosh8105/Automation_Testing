package actionMethods;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class RegisterAction {

	public static void main(String[] args) throws InterruptedException{
		
	  ChromeDriver driver=new ChromeDriver();
	  
	  driver.manage().window().maximize();
	  Thread.sleep(2000);
	  driver.get("https://demowebshop.tricentis.com/");
	  
	  
	  //verifying the page 
	  WebElement dws_icon = driver.findElement(By.className("header-logo"));
	  if(dws_icon.isDisplayed()) 
	  {
		  System.out.println("dws icon is present in the page");
		  Actions act=new Actions(driver);
		  Thread.sleep(2000);
		  
//		  WebElement register = driver.findElement(By.className("ico-register"));
//		  act.moveToElement(register).click().perform();
		  
		  act.keyDown(Keys.TAB)
		  .keyDown(Keys.TAB).keyDown(Keys.ENTER).perform();
		  
//		  act.keyDown(Keys.TAB)
//		  .keyDown(Keys.TAB)
//		  .keyDown(Keys.TAB).click().perform();
		  
		  WebElement select = driver.findElement(By.xpath("//input[@id='gender-male']"));
	       act.click(select).perform();
		  
		  WebElement fname = driver.findElement(By.xpath("//input[@id='FirstName']"));
		  act.sendKeys(fname,"varad").perform();
		  
		  WebElement last_name = driver.findElement(By.cssSelector("input[id='LastName']"));
			act.sendKeys(last_name,"Patil").perform();
		  
		  WebElement email = driver.findElement(By.cssSelector("input[id='Email']"));
			act.sendKeys(email,"varada@gmail.com").perform();
			
			WebElement password = driver.findElement(By.cssSelector("input[id='Password']"));
			act.sendKeys(password,"P@ss12345").perform();
			
			WebElement confirmpass = driver.findElement(By.cssSelector("input[id='ConfirmPassword']"));
			act.sendKeys(confirmpass,"P@ss12345");
			
			//checking the register button
			 WebElement register = driver.findElement(By.cssSelector("input[id='register-button']"));
			act.click(register).perform();
		  
		  
	}
	  else{
		  System.out.println("dws icon is not present in the page");
	  }

	  
	  Thread.sleep(2000);
      driver.close();
	  
	  
	   
		

	}

}
