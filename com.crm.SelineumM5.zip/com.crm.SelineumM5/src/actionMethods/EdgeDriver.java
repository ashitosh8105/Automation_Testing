package actionMethods;

public class EdgeDriver extends WebDriver {

}
