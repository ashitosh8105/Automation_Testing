package javaScript_Excutor;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Scroll_Into_View {

	public static void main(String[] args) throws InterruptedException {
		
		
		ChromeDriver driver=new ChromeDriver();
				
				driver.manage().window().maximize();
				
				driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		      
				driver.get("https://omayo.blogspot.com/");
				
				JavascriptExecutor js=(JavascriptExecutor) driver;
				
				WebElement drop_down = driver.findElement(By.xpath("//button[text()='Dropdown']"));
				
				//scrolling page using scrollIntoview
				js.executeScript("arguments[0].scrollIntoView(false);",drop_down);
				
				Thread.sleep(1000);
				
				js.executeScript("arguments[0].scrollIntoView(false);",drop_down);
				

	}

}
