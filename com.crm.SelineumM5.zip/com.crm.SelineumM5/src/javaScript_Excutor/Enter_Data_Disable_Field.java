package javaScript_Excutor;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Enter_Data_Disable_Field {

	public static void main(String[] args) throws InterruptedException {
           String expected_url = "https://demoapp.skillrary.com/";
		ChromeDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		
		driver.get("https://demoapp.skillrary.com/");
		Thread.sleep(2000);
		String actual_url = driver.getCurrentUrl();
		if(actual_url.equals(expected_url)) 
	{
		
		JavascriptExecutor js=(JavascriptExecutor) driver;
		
		WebElement disable_ele = driver.findElement(By.xpath("/html/body/div[1]/div/div/section/div/div[1]/div[2]/div/div[2]/form/div/input"));
		disable_ele.click();
		
		
		js.executeScript("argument[0].value='hello become a sub';",disable_ele);
		
	}
		
		
		
	}

}
