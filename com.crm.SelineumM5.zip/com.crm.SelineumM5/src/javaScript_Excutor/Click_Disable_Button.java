package javaScript_Excutor;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Click_Disable_Button {

	
	public static void main(String[] args) throws InterruptedException 
	{
		ChromeDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		
		driver.get("https://www.oracle.com/in/java/technologies/downloads/");
		
		//use javaScript executor to click disable button
		JavascriptExecutor js=(JavascriptExecutor) driver;
		
		WebElement scroll = driver.findElement(By.xpath("//a[@data-lbl='documentation-java17']"));
		
		js.executeScript("arguments[0].scrollIntoView(false);",scroll);
		Thread.sleep(2000);
		
		WebElement Lock_jdk = driver.findElement(By.linkText("jdk-17.0.14_linux-x64_bin.rpm"));
		Lock_jdk.click();
		
		WebElement disble_Element = driver.findElement(By.linkText("Download jdk-17.0.14_linux-x64_bin.rpm"));
		js.executeScript("argument[0].click();",disble_Element);
		
		
		
		
	}
	
	
	
      



	}


