package WebElementMethod;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class VerifyIcon 
{
public static void main(String[] args) throws InterruptedException {
		
		//open the chrome browser
		ChromeDriver driver=new ChromeDriver();
		
		//maximixe the browser
		driver.manage().window().maximize();
		Thread.sleep(3000);
		
		//get url
		driver.get("https://demowebshop.tricentis.com/");
		Thread.sleep(3000);
		
		//find element
		WebElement dws_icon = driver.findElement(By.className("header-logo"));
		
		//isDisplyed:
		//this method used to  check wether is webelement is  present or not in the page
		
		if(dws_icon.isDisplayed()){
			System.out.println("DWS ICON IS DISPLAYED IN THE PAGE");
			
			//isEnabled:
			   //This method to check wether the weelement is enabled or not
			    //we checl the register link is enables 
			WebElement register = driver.findElement(By.cssSelector("a[class='ico-register']"));
			
			if(register.isEnabled())
			{
				System.out.println("Register link is Enabled");
				register.click();
				driver.navigate().back();
				
				//isselected:
				   //This method used to wether the web element is selcted or not
				 WebElement excellent = driver.findElement(By.id("pollanswers-1"));
				 excellent.click();
				 
				 if(excellent.isSelected()) 
				 {
					 System.out.println("Excellent radio button is seleted");
				 }
				 else {
					 System.out.println("Excellent radio button is not selected");
					 
				 }
			}
			else {
				System.out.println("Register link is not enabled");
			}
	}
		else
		{
			System.out.println("DWS ICON IS NOT DISPLYED IN THE PAGE");
		}
		
		
		Thread.sleep(3000);
		driver.close();		
		

	}

}
