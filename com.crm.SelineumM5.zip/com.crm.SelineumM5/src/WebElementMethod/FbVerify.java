package WebElementMethod;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
public class FbVerify{
	public static void main(String[] args) throws InterruptedException {
		
		//open the browser
		ChromeDriver driver=new ChromeDriver();
		
	   //maximize the browser
		driver.manage().window().maximize();
		Thread.sleep(2000);
		//get url
		driver.get("https://www.facebook.com/");
		

		 driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[1]/div/div/div/div[2]/div/div[1]/form/div[5]/a")).click();
		 
		 WebElement fname = driver.findElement(By.xpath("//input[@name='firstname']"));
		 fname.sendKeys("Ashitosh");
		 
		 WebElement surname = driver.findElement(By.xpath("//input[@name='lastname']"));
             surname.sendKeys("Jagtap");
		  driver.findElement(By.xpath("//select[@id='day']")).click();
		  
		  //we have used select class method to select dropdown menu
		  WebElement select_Day = driver.findElement(By.xpath("//select[@id='day']"));
		  
		  Select sel=new Select(select_Day);
		  sel.selectByValue("1");
		  
		  WebElement select_month = driver.findElement(By.xpath("//select[@id='month']"));
		  
		  Select sel1=new Select(select_month);
		  sel1.selectByVisibleText("Mar");
		  
		  WebElement select_year = driver.findElement(By.xpath("//select[@id='year']"));
		  
		  Select sel2=new Select(select_year);
		  sel2.selectByValue("2002");
		  
		  
		  
		  
//        driver.findElement(By.xpath("//div[text()='Date of birth']/..//following-sibling::div[1]/span/span/select/option")).click();
            
//        driver.findElement(By.xpath("//div[text()='Date of birth']/..//following-sibling::div[1]/span/span/select[2]/option[3]")).click();
//        driver.findElement(By.xpath("//div[text()='Date of birth']/..//following-sibling::div[1]/span/span/select[3]/option[24]")).click();
//            
          driver.findElement(By.xpath("//div[text()='Gender']/..//following-sibling::span/span[2]/label/input")).click();

           WebElement mb = driver.findElement(By.xpath("//input[@name='reg_email__']")); 
           mb.sendKeys("jagtapshivaji8105@gmail.com");
           
           WebElement pass = driver.findElement(By.xpath("//input[@name='reg_passwd__']"));
           pass.sendKeys("Pass@5018");
           
           
           
//           driver.findElement(By.xpath("//button[@name='websubmit']")).click();
           driver.navigate().back();
           
           
           WebElement fb_logo = driver.findElement(By.xpath("//img[@alt='Facebook']"));
           if(fb_logo.isDisplayed()){
        	   System.out.println("Facebook logo is displyed in the page");
        	   WebElement uname = driver.findElement(By.xpath("//input[@id='email']"));
        	   uname.sendKeys("jagtapshivaji8105@gmail.com");
        	   
        	   WebElement upass = driver.findElement(By.xpath("//input[@id='pass']"));
        	   upass.sendKeys("Pass@5018");
        	   
        	   driver.findElement(By.xpath("//button[@name='login']")).click();
        	    
        	  }else {
        	   System.out.println("FB logo is not visible");
        	 
           }
          
           
	Thread.sleep(20000);
    driver.close();
	}

}
