package WebElementMethod;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class VerifWebEle {

	public static void main(String[] args) throws InterruptedException {
		
             ChromeDriver driver=new ChromeDriver();
             
             driver.manage().window().maximize();
             Thread.sleep(2000);
             
             driver.get("https://demowebshop.tricentis.com/");
             
             Thread.sleep(2000);
             
              WebElement dws_icon = driver.findElement(By.className("header-logo")); 
              
              if(dws_icon.isDisplayed()) {
            	  
            	  System.out.println("DWS ICON IS PRESENT IN THE PAGE");
            	  WebElement register = driver.findElement(By.cssSelector("a[class='ico-register']"));
            	  
            	  if(register.isEnabled()) 
            	  {
            		  System.out.println("REGISTER LINK IS ENABLED");
            		  register.click();
            		  
            		    WebElement gender = driver.findElement(By.cssSelector("input[id='gender-male']"));
            		    gender.click();
            		    
            		    if(gender.isSelected()) 
            		    {
            		    	System.out.println("RADIO BUTTON IS SELECTED");
            		    }
            		    else	
            		    {
            		    	System.out.println("RADIO BUTTON IS NOT SELECTED");
            		    }
            		  
            	  }
            	  else {
            	 	     System.out.println("RESITER PAGE IS DISABLED");
            	     }
            	  
            	  
              }
              else{
            	  System.out.println("DWS ICON IS NOT PRESENT IN THE PAGE");
              }
              
              Thread.sleep(2000);
              driver.close();
	}

}
