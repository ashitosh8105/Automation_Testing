package MockTest;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class BaseClass {


	public static WebDriver driver=null;
    public static String browser="chrome";
    
    public static void precondition() 
    {
    	
    	if(browser.equalsIgnoreCase("chrome")) {
 		   driver=new ChromeDriver();
 	   }else if(browser.equalsIgnoreCase("edge")) {
 		   driver=new EdgeDriver();
 	   }else if(browser.equalsIgnoreCase("firefox")) {
 		   
 		   driver=new FirefoxDriver();
 	   }
 	  else{
			driver=new ChromeDriver();
		}
    	driver.manage().window().maximize();
    	//implicit wait
    	
    	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
    	//enter URL
    	driver.get("https://demowebshop.tricentis.com/");
   
    }
    
    public static void login() {
    	
    	driver.findElement(By.className("ico-login")).click();
 	   driver.findElement(By.id("Email")).sendKeys("ashitosh123456@gmail.com");
 	   driver.findElement(By.id("Password")).sendKeys("P@ss1234");
 	   driver.findElement(By.id("RememberMe")).click();
 	   driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
 	   
    }
    public static void logout() {
    	
    	driver.findElement(By.className("ico-logout")).click();
    }
    public static void close() {
    	driver.quit();
    }
    
	}
	

    
    
    


