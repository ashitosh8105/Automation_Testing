package MockTest;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class Task1 extends  BaseClass{

	public static void main(String[] args) throws InterruptedException  {
		String expected_url="https://demowebshop.tricentis.com/";
		precondition();
	
		String actual_url=driver.getCurrentUrl();
		if(actual_url.equals(expected_url)) {
			
			login();
			
			Actions act=new Actions(driver);
			act.keyDown(Keys.PAGE_DOWN).perform();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//input[@value='Add to cart']")).click();
			
			 WebElement rname = driver.findElement(By.className("recipient-name"));
			 rname.sendKeys("ashitosh");
			 
			 WebElement remail = driver.findElement(By.className("recipient-email"));
			 remail.sendKeys("ashitosh123@gmail.com");
			 
			 Actions act1=new Actions(driver);
			 
			 act.keyDown(Keys.PAGE_DOWN).perform();
			 
			 WebElement qty = driver.findElement(By.className("qty-input"));
			 qty.clear();
			 
			 qty.sendKeys("2");
			 Thread.sleep(2000);
			 driver.findElement(By.xpath("//*[@id=\"add-to-cart-button-2\"]")).click();
			 
			 WebElement carts = driver.findElement(By.xpath("//span[@class='cart-qty']"));
			 System.out.println(carts.getText());
			 
//			 if(carts.g) {
//				 System.out.println("Cart is added sucessfully");
//			 }else {
//				 System.out.println("cart is not added ");
//			 }
			 
			 logout();
			 close();
			 
			 
			
		}

	}

}
