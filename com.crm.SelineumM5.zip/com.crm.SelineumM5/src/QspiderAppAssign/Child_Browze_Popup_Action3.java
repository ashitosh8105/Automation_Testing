
package QspiderAppAssign;

import java.awt.AWTException;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Child_Browze_Popup_Action3
{
	
	public static void main(String[] args) throws InterruptedException, AWTException 
{
		
	//  Open the Browser
	 ChromeDriver driver = new ChromeDriver();
	//maximize the browser
		driver.manage().window().maximize();
	//waiting condition
		Thread.sleep(2000);
	// Enter into demoapps url
		driver.get("https://demoapps.qspiders.com/");
		
		Robot r = new Robot();
		
	// Create action class object to aceess all the action class methods
		Actions act = new Actions(driver);
		
	// find the current page's window Handle and store it in a variable using getWindowHandle() method
		 String parent_handle= driver.getWindowHandle();
				
		 System.out.println(parent_handle);

		Thread.sleep(2000);
		
	// Target UI Testing Element and Click 
		driver.findElement(By.xpath("//p[text()='UI Testing Concepts']")).click();
			
		Thread.sleep(2000);
			
	// Target Popups Element and Click the dropdown
		driver.findElement(By.xpath("//section[text()='Popups']")).click();
		Thread.sleep(2000);
		
	// Target Browser Windows Element from  the dropdown and Click it
		driver.findElement(By.xpath("//section[text()='Browser Windows']")).click();
		Thread.sleep(2000);
		
		
	// Target New Windows Element and Click it
		driver.findElement(By.xpath("//a[text()='Multiple Windows']")).click();
		Thread.sleep(2000);
		
		act.keyDown(Keys.PAGE_DOWN).perform();
	// Target Open in new window button and Click it
		driver.findElement(By.id("browserButton3")).click();
		
	// find the child page's and current page's window Handle and store it in a set Type of variable using getWindowHandle() method
		 Set<String> child_handle= driver.getWindowHandles();
		 		
		System.out.println(child_handle);
			
	// we get multiple data inside the child_handle we need to remove the parent handle from child_handle set
		child_handle.remove(parent_handle);
				
				String window1 = "https://demoapps.qspiders.com/ui/browser/SignUpPage";
				String window2 = "https://demoapps.qspiders.com/ui/browser/SignUp";
				String window3 = "https://demoapps.qspiders.com/ui/browser/Login";
				
	// Window Handles
				 String window1_handle ="";
				 String window2_handle ="";
				 String window3_handle ="";
				
		// to Switch driver from one tab to another tab we have to use folowing syntax

				 
	for (String str : child_handle) 
			{
					
			 driver.switchTo().window(str);
					
				if(window1.equals(driver.getCurrentUrl()))
				{
					window1_handle= driver.getWindowHandle();
						
					System.out.println(window1_handle);
						
				// Target email textfield and send text
					driver.findElement(By.id("email")).sendKeys("demo123@gmail.com");
						
					Thread.sleep(2000);
						
			// Target Password textfield and send text
					driver.findElement(By.id("password")).sendKeys("demo123");
					Thread.sleep(2000);
						
			// Target Confirm Password textfield and send text
					driver.findElement(By.id("confirm-password")).sendKeys("demo123");
					Thread.sleep(2000);
						
						// Target signup button and click	
					act.keyDown(Keys.TAB).keyDown(Keys.ENTER).perform();
					Thread.sleep(2000);
						
						//close the browser
						driver.close();
						
					}
					else if (window2.equals(driver.getCurrentUrl())) 
					{	
						window2_handle= driver.getWindowHandle();
						
						System.out.println(window2_handle);
						
						// Target Name textfield and send text
						
						driver.findElement(By.id("username")).sendKeys("Ashitoshjagtap");
						Thread.sleep(2000);
						
						// Target email textfield and send text
						driver.findElement(By.id("email")).sendKeys("demo123@gmail.com");
						
						Thread.sleep(2000);
						
						// Target Password textfield and send text
						driver.findElement(By.id("password")).sendKeys("demo123");
						Thread.sleep(2000);
						
						// Target signup button and click						
						act.keyDown(Keys.TAB).keyDown(Keys.ENTER).perform();
						Thread.sleep(2000);
						
						//close the browser
						driver.close();
						
					} 
					else 
					{
						window3_handle= driver.getWindowHandle();
							
						System.out.println(window3_handle);
							
							
					// Target email textfield and send text
					driver.findElement(By.id("username")).sendKeys("Ashitoshjagtap");
							
					Thread.sleep(2000);
							
				// Target Password textfield and send text
					driver.findElement(By.id("password")).sendKeys("demo123");
					Thread.sleep(2000);
							
					// Target Login button and click using action class
							
					act.keyDown(Keys.TAB).keyDown(Keys.ENTER).keyUp(Keys.TAB).keyUp(Keys.ENTER).perform();
					Thread.sleep(2000);
							
							//close the browser
					driver.close();
							
					}
	
					
				}
				
				
				driver.switchTo().window(parent_handle);
			
				Thread.sleep(2000);
				
				//close the Browser
				driver.close();
		
	}

}
