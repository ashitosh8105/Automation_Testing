package QspiderAppAssign;

import java.util.Set;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Child_Browser_Popup_Action1 
{

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
ChromeDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		driver.get("https://demoapps.qspiders.com/");
		Thread.sleep(2000);
//	
		String parent_handle = driver.getWindowHandle();
		System.out.println(parent_handle);
		
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[text()='UI Testing Concepts']")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//section[text()='Popups']")).click();
            
		Thread.sleep(2000);
		driver.findElement(By.xpath("//section[text()='Browser Windows']")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//a[text()='New Window']")).click();
		Thread.sleep(2000);
		//scroll the page
		
		Actions act=new Actions(driver);
		act.keyDown(Keys.PAGE_DOWN).perform();
		
		driver.findElement(By.xpath("//a[text()='Open in new window']")).click();
		

		
		Set<String> child = driver.getWindowHandles();
		child.remove(parent_handle);
		for (String string : child) 
		{
			driver.switchTo().window(string);
		} 
		Thread.sleep(2000);
		
		 WebElement email = driver.findElement(By.xpath("//input[@id='email']"));
				email.sendKeys("jagtap123@gmail.com");
				Thread.sleep(1000);
		  WebElement pass = driver.findElement(By.xpath("//input[@id='password']"));
		  pass.sendKeys("Passs@134");
		  
		  Thread.sleep(1000);
		  WebElement confPass = driver.findElement(By.xpath("//input[@id='confirm-password']"));
		  confPass.sendKeys("Passs@134");
		  
		  Thread.sleep(2000);
		  driver.findElement(By.xpath("//button[text()='Sign Up']")).click();
		  
		driver.quit();

	}

}
