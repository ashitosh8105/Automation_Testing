package QspiderAppAssign;

import java.awt.AWTException;
import java.awt.Robot;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Child_Browze_Popup_Action4 {

	public static void main(String[] args) throws InterruptedException, AWTException {
		
		//  Open the Browser
	 ChromeDriver driver = new ChromeDriver();
	//maximize the browser
		driver.manage().window().maximize();
	//waiting condition
		Thread.sleep(2000);
	// Enter into DWS page
		driver.get("https://demoapps.qspiders.com/");
		
		Robot r = new Robot();
		
	
	// find the current page's window Handle and store it in a variable using getWindowHandle() method
		 String parent_handle= driver.getWindowHandle();
				
		 System.out.println(parent_handle);

		 Thread.sleep(2000);
		
	// Target UI Testing Element and Click 
		driver.findElement(By.xpath("//p[text()='UI Testing Concepts']")).click();
			
		Thread.sleep(2000);
			
	// Target Popups Element and Click the dropdown
		driver.findElement(By.xpath("//section[text()='Popups']")).click();
		Thread.sleep(2000);
		
	// Target Browser Windows Element from  the dropdown and Click it
		driver.findElement(By.xpath("//section[text()='Browser Windows']")).click();
		Thread.sleep(2000);
		 
		//open muntiple tags and handle it
		driver.findElement(By.xpath("//a[text()='Multiple Tabs']")).click();
		
		// Create action class object to aceess all the action class methods
		Actions act = new Actions(driver);
		
		act.keyDown(Keys.PAGE_DOWN).perform();
	
		driver.findElement(By.xpath("//button[@id='browserButton2']")).click();
		
		
		
		
	}

}
