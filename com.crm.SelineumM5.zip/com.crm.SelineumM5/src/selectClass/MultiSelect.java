package selectClass;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class MultiSelect{

	public static void main(String[] args) throws InterruptedException {
		
		
	 ChromeDriver driver=new ChromeDriver();
	 
	 driver.manage().window().maximize();
	 Thread.sleep(2000);
	 
	 driver.get("C:\\Automation\\DemoFile\\demo%20(2).html");
	 Thread.sleep(2000);
	 
	 
	 //select multiple values 
	 WebElement multi_select = driver.findElement(By.id("multiple_cars"));
	 
	 //create a object select class
	 Select sel=new Select(multi_select);
	 
	
	 sel.selectByVisibleText("Honda");
	 Thread.sleep(2000);

	 sel.selectByValue("bmw");
	 Thread.sleep(2000);
	 
	 sel.selectByIndex(3);//ford
	 Thread.sleep(2000);
	 
	 //deselect method
	 sel.deselectByVisibleText("Honda");
	 Thread.sleep(2000);

	 sel.deselectByValue("bmw");
	 Thread.sleep(2000);
	 
	 sel.deselectByIndex(3);//ford
	 Thread.sleep(2000);
	 
	 sel.deselectAll();
	 
	 Thread.sleep(2000);
	 
     driver.close();
	 
	 
	 
	 
	}

}
