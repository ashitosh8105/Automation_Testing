package selectClass;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class Task {

	public static void main(String[] args) throws InterruptedException 
	{
		
		String expected_url="https://demo.automationtesting.in/Register.html";
		ChromeDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		
		Thread.sleep(2000);
		
		driver.get("https://demo.automationtesting.in/Register.html");
		
		String actual_url=driver.getCurrentUrl();
		
		if(actual_url.equals(expected_url)) {
			System.out.println("Register Page verified succesfully");
			
			WebElement fname = driver.findElement(By.xpath("/html/body/section/div/div/div[2]/form/div[1]/div[1]/input"));
			fname.sendKeys("Ahitosh");
			
			WebElement lname = driver.findElement(By.xpath("/html/body/section/div/div/div[2]/form/div[1]/div[2]/input"));
			lname.sendKeys("Jagtap");
			
			WebElement add = driver.findElement(By.xpath("//textarea[@ng-model='Adress']"));
			add.sendKeys("Kolhapur");
			
			WebElement email = driver.findElement(By.xpath("//input[@ng-model='EmailAdress']"));
			email.sendKeys("Demo123@gmail.com");
			
			WebElement phno = driver.findElement(By.xpath("//input[@ng-model='Phone']"));
			phno.sendKeys("8969857422");
			
			driver.findElement(By.xpath("//input[@value='Male']")).click();
			
			driver.findElement(By.xpath("//input[@id='checkbox2']")).click();
			driver.findElement(By.xpath("//input[@id='checkbox1']")).click();
			
  
			
//			driver.get("https://demo.automationtesting.in/Register.html");
			Thread.sleep(2000);
			
//			driver.manage().window().maximize();
			
			
			 WebElement select_skill = driver.findElement(By.xpath("//select[@id='Skills']"));
			 
			 //create a object select class
			 Select sel1=new Select(select_skill);
			
			 //select the option using selectByvisibleText method
			 sel1.selectByValue("APIs");
			 
			 WebElement select_country = driver.findElement(By.xpath("//select[@id='country']"));
			 
			 Select sel2=new Select(select_country);
			 sel2.selectByVisibleText("India");
			 
			 Actions act=new Actions(driver);
				Thread.sleep(1000);
				act.keyDown(Keys.PAGE_DOWN).keyUp(Keys.PAGE_DOWN).perform();//scrolling the page 
				act.keyDown(Keys.PAGE_UP).keyUp(Keys.PAGE_UP).perform();
			 

			 WebElement select_year = driver.findElement(By.xpath("//select[@id='yearbox']"));
			 
			 Select sel3=new Select(select_year);
			 sel3.selectByValue("2002");
			 

			 WebElement select_month = driver.findElement(By.xpath("//select[@ng-model='monthbox']"));
			 
			 Select sel4=new Select(select_month);
			 sel4.selectByValue("March");
			 
            WebElement select_day = driver.findElement(By.xpath("//select[@id='daybox']"));
			 
			 Select sel5=new Select(select_day);
			 sel5.selectByVisibleText("1");
			 
			 WebElement pass = driver.findElement(By.xpath("//input[@id='firstpassword']"));
			 
			 pass.sendKeys("Pass@123");
			 
            WebElement confpass = driver.findElement(By.xpath("//input[@id='secondpassword']"));
			 
			 confpass.sendKeys("Pass@123");
			 
			 driver.findElement(By.xpath("//button[@id='submitbtn']")).click();
			 
			 
			   
			 
	}else {
			System.out.println("Expected page is not visible");
		}
		Thread.sleep(2000);
		driver.close();

	}

}
