package selectClass;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SingleSelect {

	public static void main(String[] args) throws InterruptedException {
		
		
	 ChromeDriver driver=new ChromeDriver();
	 
	 driver.manage().window().maximize();
	 Thread.sleep(2000);
	 
	 driver.get("C:\\Automation\\DemoFile\\demo%20(2).html");
	 Thread.sleep(2000);
	 
	 WebElement single_select = driver.findElement(By.id("standard_cars"));
	 
	 //create a object select class
	 Select sel=new Select(single_select);
	 
	 //select the option using selectByvisibleText method
	 sel.selectByVisibleText("Honda");
	 Thread.sleep(2000);
	 
	 //select option using value
	 sel.selectByValue("bmw");
	 Thread.sleep(2000);
	 
	 //select option using index
	 sel.selectByIndex(4);//honda
	 
	 if(sel.isMultiple())//verify the dropdown menu we use isMultiple Method 
	 {
		 sel.deselectAll();
	 }else {
		 System.out.println("It is a single select dropdown menu");
	 }
	 
//	 sel.deselectByIndex(4); //UnsupportedOperationException
	 Thread.sleep(2000);
	 driver.close();
	 
	 
	 
	 
	}

}
