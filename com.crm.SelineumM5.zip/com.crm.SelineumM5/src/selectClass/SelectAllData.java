package selectClass;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SelectAllData 
{
  public static void main(String[] args) throws InterruptedException {
	 	
		
		 ChromeDriver driver=new ChromeDriver();
		 
		 driver.manage().window().maximize();
		 Thread.sleep(2000);
		 
		 driver.get("C:\\Automation\\DemoFile\\demo%20(2).html");
		 Thread.sleep(2000);
		 
		 
		 //select multiple values 
		 WebElement multi_select = driver.findElement(By.id("multiple_cars"));
		 
		 Select sel=new Select(multi_select);
		 List<WebElement>options=sel.getOptions();
		 //return type of getOption is listwebElement   (imp Q for mock)
		 int i=0;
		 for(WebElement web:options) {
			 sel.selectByIndex(i++);
			 Thread.sleep(2000);
		 }
		 
		 Thread.sleep(2000);
		 driver.close();
		 
		 
	}
}
