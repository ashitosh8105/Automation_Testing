package selectClass;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DWSSelectMethod {

	public static void main(String[] args) throws InterruptedException {
		
		String expected_url="https://demowebshop.tricentis.com/";
		ChromeDriver driver=new ChromeDriver();
		Thread.sleep(2000);
		driver.manage().window().maximize();
		
		driver.get("https://demowebshop.tricentis.com/");
		
		String actual_url=driver.getCurrentUrl();
		
		if(actual_url.equals(expected_url)) {
			
			System.out.println("Page verified successfully");
			
	//we can use "xpath by contins" method by selecting the element bcz there is more space after the text 
			driver.findElement(By.xpath("//a[contains(text(),'Digital downloads')]")).click();
			
			//
			
			   WebElement position = driver.findElement(By.xpath("//select[@id='products-orderby']"));
			   Select sel=new Select(position);
				 List<WebElement>options=sel.getOptions();
				 //return type of getOption is listwebElement   (imp Q for mock)
				 int i=0;
				 for(WebElement web:options) {
					 
					 //we can passing the findelement again in the loop bcz its a dynamic page after 2sec it will changed the options
					 position = driver.findElement(By.xpath("//select[@id='products-orderby']"));
					 sel=new Select(position);
					 sel.selectByIndex(i++);
					 Thread.sleep(2000);
				 }
	
			   
//			   WebElement display = driver.findElement(By.xpath("//select[@id='products-pagesize']"));
//			    Select sel2=new Select(display);
//			    List<WebElement>options1=sel.getOptions();
//			    for(WebElement web:options1) {
//			    	display = driver.findElement(By.xpath("//select[@id='products-pagesize']"));
//			    	sel2=new Select(display);
//			    	sel2.selectByIndex(i++);
//			    	Thread.sleep(2000);
//			    }
			    
//			    
//			    sel2.selectByVisibleText("12");
//			    
//			    WebElement view_as = driver.findElement(By.xpath("//select[@id='products-viewmode']"));
//			    
//			    Select sel3=new Select(view_as);
//			    sel3.selectByVisibleText("List");
			    }else 
			    {
			System.out.println("DWS page not visible");
		}
		Thread.sleep(2000);
		driver.close();
		
	}

}
