package iFrame;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Task3 {

	public static void main(String[] args) throws InterruptedException {
		//tesk3
		 //wasf iframe demo page
		 //open browser
		 //maximize
		 //enter url
		 //click ecom link page by using find elements
		 //click create new ac in facebook
		 //send some value inside DWS text field and click searchbutton 
		 //click google link which is present in the main page
		
		String expected_fb_url = "https://www.facebook.com/nopCommerce";
		String expected_ecom_url = "https://x.com/nopCommerce?mx=2";
		String expected_Youtube_url = "https://www.youtube.com/user/nopCommerce";
		String expected_google_url = "https://workspaceupdates.googleblog.com/";
		
		ChromeDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		driver.get("file:///C:/Users/Ashitosh/Downloads/iframe%20(1).html");
		
		Thread.sleep(2000);
		
		//entering into iframe
	    driver.switchTo().frame("frame1");
	    
	    Thread.sleep(2000);
	    
	    Actions act=new Actions(driver);
	    act.keyDown(Keys.PAGE_DOWN).perform();
	    Thread.sleep(2000);
	    //handling child browser popup
	    
	     String parent_handle = driver.getWindowHandle();
	    
	    List<WebElement> follow_us = driver.findElements(By.xpath("//a[@target='_blank']"));
		
		for(WebElement web : follow_us){
			
			
			web.click();
			Thread.sleep(2000);
			
			Set<String> child_handle = driver.getWindowHandles();
			child_handle.remove(parent_handle);
		
			for (String str : child_handle) {
				
				String actual_fb_ur = driver.getCurrentUrl();
				String actual_ecom_url = driver.getCurrentUrl();
				String actual_Youtube_url = driver.getCurrentUrl();
				String actual_google_url = driver.getCurrentUrl();
				
				if(expected_fb_url.equals(actual_fb_ur)){
					
					
					driver.findElement(By.xpath("//span[text()='Create new account']")).click();
					
				}
				else if(expected_ecom_url.endsWith(actual_ecom_url)){
					
					driver.close();
					
				}
				else if(expected_Youtube_url.equals(actual_Youtube_url)){
					
					driver.close();
				}
				else if(expected_google_url.equals(actual_google_url)) {
					
					driver.close();
			}
					
				
			}
			
		}
	     
//		driver.close();
	}

}
