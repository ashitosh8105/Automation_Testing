package iFrame;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Qsp_Iframe_Assign4 {

	public static void main(String[] args) throws InterruptedException {
		

	       ChromeDriver driver=new ChromeDriver();
	       
	       driver.manage().window().maximize();
	       Thread.sleep(2000);
	       
	       driver.get("https://demoapps.qspiders.com/");
	       
	       Thread.sleep(2000);
	       driver.findElement(By.xpath("//p[text()='UI Testing Concepts']")).click();
	       Thread.sleep(2000);
//	       
//	       
	       driver.findElement(By.xpath("//section[text()='Frames']")).click();
	       Thread.sleep(2000);
////	       
	       driver.findElement(By.xpath("//section[text()='iframes']")).click();
	       Thread.sleep(2000);
	       
	       driver.findElement(By.xpath("//a[text()='Nested with Multiple iframe']")).click();
	       Thread.sleep(2000);
	       
	       driver.switchTo().frame(0);
	       Thread.sleep(2000);
	       
	       
	       WebElement second_iframe = driver.findElement(By.xpath("//div[@class='form_container']//iframe"));
	       driver.switchTo().frame(second_iframe);
	       Thread.sleep(2000);
	       
	       WebElement third_iframe = driver.findElement(By.xpath("//div[@class='form-group']/iframe"));
	       driver.switchTo().frame(third_iframe);
	       Thread.sleep(2000);
	       
	       driver.findElement(By.xpath("//input[@id='email']")).sendKeys("ashitosh123@gmail.com");
	       Thread.sleep(2000);
//	       
	       driver.switchTo().parentFrame();
	       Thread.sleep(2000);
	       
	       WebElement fourth_iframe = driver.findElement(By.xpath("/html/body/div/div/form/div[2]/iframe"));
	       driver.switchTo().frame(fourth_iframe);
	       Thread.sleep(2000);
	       
//	       driver.switchTo().frame(3);
	       Thread.sleep(2000);
	       
	       driver.findElement(By.xpath("//input[@id='password']")).sendKeys("P@ss123");
	       Thread.sleep(2000);
	       
	       Actions act=new Actions(driver);
	       
	       act.keyDown(Keys.PAGE_DOWN).perform();
	       Thread.sleep(2000);
	       
	       driver.switchTo().parentFrame();
	       
	       WebElement fifth_iframe = driver.findElement(By.xpath("/html/body/div/div/form/div[3]/iframe"));
	       driver.switchTo().frame(fifth_iframe);
	       
	       Thread.sleep(2000);
	       
	       driver.findElement(By.xpath("//input[@id='confirm']")).sendKeys("P@ss123");
	       
	       Thread.sleep(2000);
	       
	       driver.switchTo().parentFrame();
	       
	       WebElement sixth_iframe = driver.findElement(By.xpath("/html/body/div/div/form/div[4]/iframe"));
	       driver.switchTo().frame(sixth_iframe);
	       
	       Thread.sleep(2000);
	       driver.findElement(By.xpath("//button[text()='Submit']")).click();
	       
	       driver.switchTo().defaultContent();
	       
	       //	       driver.close();
	}     
	

}
