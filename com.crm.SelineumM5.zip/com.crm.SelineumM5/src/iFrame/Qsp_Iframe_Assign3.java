package iFrame;

import org.openqa.selenium.By;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Qsp_Iframe_Assign3{

	public static void main(String[] args) throws InterruptedException {
		
		ChromeDriver driver=new ChromeDriver();
	       
	       driver.manage().window().maximize();
	       Thread.sleep(2000);
	       
	       driver.get("https://demoapps.qspiders.com/");
	       
	       Thread.sleep(2000);
	       driver.findElement(By.xpath("//p[text()='UI Testing Concepts']")).click();
	       Thread.sleep(2000);
	       
	       
	       driver.findElement(By.xpath("//section[text()='Frames']")).click();
	       Thread.sleep(2000);
	       
	       driver.findElement(By.xpath("//section[text()='iframes']")).click();
	       Thread.sleep(2000);
	       
	       driver.findElement(By.xpath("//a[text()='Multiple iframe']")).click();
	       Thread.sleep(2000);
//	     
	       WebElement first_iframe = driver.findElement(By.xpath("//div[@class='w-1/2']/iframe"));
	       driver.switchTo().frame(first_iframe);
	       Thread.sleep(2000);
	       
	       driver.findElement(By.id("email")).sendKeys("ashitosh123@gmail.com");
	       Thread.sleep(2000);
	       
	       driver.findElement(By.xpath("//section[@class='eyeParent']/input")).sendKeys("P@ss123");
	       Thread.sleep(2000);
	       
	       driver.findElement(By.xpath("//input[@name='confirmPassword']")).sendKeys("P@ss123");
	       Thread.sleep(2000);
	       
	       driver.findElement(By.id("submitButton")).click();
	       Thread.sleep(2000);
	       
	       driver.switchTo().defaultContent();
	       Thread.sleep(2000);
	       
	       driver.switchTo().frame(1);
	       
	       driver.findElement(By.id("username")).sendKeys("ashitosh");
	       Thread.sleep(2000);
	       
	       driver.findElement(By.xpath("/html/body/div/div/div/form/div[2]/section/input")).sendKeys("P@ss123");
	       Thread.sleep(2000);
	       
	       driver.findElement(By.xpath("//button[text()='Login']")).click();
	       Thread.sleep(2000);
	       
	       driver.switchTo().parentFrame();
	       Thread.sleep(2000);
	       
	       driver.close();
	}

}
