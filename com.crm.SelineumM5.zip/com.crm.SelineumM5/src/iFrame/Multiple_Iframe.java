package iFrame;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Multiple_Iframe {

	public static void main(String[] args) throws InterruptedException {
		//If we want to back to the parentpage from the iframe we use 
		  //->parentframe();
		      //syntax:driver.switchTo.parentframe();
		
		  //->defaultcontent();
		    //syntax:driver.switchTo.defaultcontent();
		
	ChromeDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		Thread.sleep(2000);
		//get url
		driver.get("https://www.dream11.com/");
		Thread.sleep(2000);
		
		driver.switchTo().frame(0);

		WebElement mobNo = driver.findElement(By.xpath("//input[@type='email']"));
		mobNo.sendKeys("9874563212");
		Thread.sleep(2000);
		
		//switching the controler to the parent page
		 driver.switchTo().defaultContent();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[@id='hamburger']")).click();
		 
       //tesk3
		  //wasf iframe demo page
		 //open brow
		 //maximize
		 //enter url
		 //click ecom link page by using find elements
		 //click create new ac in facebook
		 //send some value inside DWS text field and click searchbutton 
		 //click google link which is present in the main page
	}

}
