package iFrame;

//iframe:
   //Embeded Page:
         //->One page onside another page
         //->iframe tag
