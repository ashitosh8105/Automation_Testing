package iFrame;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class NestedFrame {

	public static void main(String[] args) throws InterruptedException {

             //Passing the data in textfield which is present in nested iframe

		  ChromeDriver driver=new ChromeDriver();
			
			driver.manage().window().maximize();
			Thread.sleep(2000);
			//get url
			
			driver.get("https://demo.automationtesting.in/Frames.html");
			Thread.sleep(2000);
			
			driver.findElement(By.linkText("Iframe with in an Iframe")).click();
			Thread.sleep(2000);
			
			WebElement parent_iframe = driver.findElement(By.xpath("//div[@id='Multiple']/iframe"));
			driver.switchTo().frame(parent_iframe);
			
			Thread.sleep(2000);
			
			WebElement child_iframe = driver.findElement(By.xpath("//div[@class='iframe-container']/iframe"));
			driver.switchTo().frame(child_iframe);
			Thread.sleep(2000);
			
			driver.findElement(By.xpath("//input[@type='text']")).sendKeys("My name Ashitosh");
			
			Thread.sleep(2000);
			driver.close();

	}

}
