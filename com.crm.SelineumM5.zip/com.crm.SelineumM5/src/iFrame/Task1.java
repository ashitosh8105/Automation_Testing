package iFrame;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

//iframe:
 //Embeded Page:
      //->One page inside another page.
      //->iframe tag2

//Syntax for switch the one page to another page
// driver.switchTo().frame(arg);
      //Pasing the value of an arg is 
                      //*int->index of the frame (Index always start from 0)
                      //string->id/name attribute value
                     //weblement->ifrmae webelement
   public class Task1{

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		ChromeDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		Thread.sleep(2000);
		//get url
		driver.get("https://www.dream11.com/");
		Thread.sleep(2000);
		
	

//NOTE:IF WE WANT THE PASSING THE VALUE INSIDE THE TEXT FIELD BUT THIS TEXT FIELD PRESENT INSIDE THE 
	 //IFRAME WE NEED TO SWITH THE PAGE INSIDE THE IFRAME 
		
//	1]Method1:	
		//driver.switchTo().frame(0);	//switching the Page into iFrame
		
	
//	2]Method2:
	 //driver.switchTo().frame("send-sms-iframe");//we pass the id attribute value
		
	//3]Method3:
		driver.switchTo().frame("/html/body/section[1]/div[2]/div/iframe");
		Thread.sleep(2000);
		
		WebElement mobNo = driver.findElement(By.xpath("//input[@type='email']"));
		mobNo.sendKeys("9874563212");
		
		Thread.sleep(20000);
		driver.close();
		
		//Task:iframe demo app for automation
	
		}

}
