package iFrame;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Qsp_Iframe_Assign2 {

	public static void main(String[] args) throws InterruptedException {


	       ChromeDriver driver=new ChromeDriver();
	       
	       driver.manage().window().maximize();
	       Thread.sleep(2000);
	       
	       driver.get("https://demoapps.qspiders.com/");
	       
	       Thread.sleep(2000);
	       driver.findElement(By.xpath("//p[text()='UI Testing Concepts']")).click();
	       Thread.sleep(2000);
//	       
//	       
	       driver.findElement(By.xpath("//section[text()='Frames']")).click();
	       Thread.sleep(2000);
////	       
	       driver.findElement(By.xpath("//section[text()='iframes']")).click();
	       Thread.sleep(2000);
////	       
	       
	       driver.findElement(By.xpath("//a[text()='Nested iframe']")).click();
	       Thread.sleep(2000);
////	       
//////	       //nested iframe
////	      
	       WebElement parent_iframe = driver.findElement(By.xpath("//div[@class='px-8 pt-8 rounded-xl ']/iframe"));
	       driver.switchTo().frame(parent_iframe);
	       Thread.sleep(2000);
////	       
	       WebElement child_iframe = driver.findElement(By.xpath("//div[@class='form_container']/iframe"));
	       driver.switchTo().frame(child_iframe);
////	       
	       Thread.sleep(2000);
//	       
	       driver.findElement(By.id("email")).sendKeys("ashitosh123@gmail.com");
	       Thread.sleep(2000);
////	       
           driver.findElement(By.id("password")).sendKeys("ashi@123");
	       Thread.sleep(2000);
	       
	    driver.close();   

	}

}
