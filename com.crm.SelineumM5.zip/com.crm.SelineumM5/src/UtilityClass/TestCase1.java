package UtilityClass;

import org.openqa.selenium.By;

//public class TestCase1 extends BaseClass
public class TestCase1 extends BaseClass
{
  public static void main(String[] args) throws InterruptedException 
	{
		preCondition();
		login();
		driver.findElement(By.id("small-searchterms")).sendKeys("Iphone13");
		driver.findElement(By.cssSelector(".button-1.search-box-button")).click();
		login();
		 postCondition();
		 
		 
		 
		

	}

}
