package pop_up;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Calender_Popup 
{
	public static void main(String[] args) throws InterruptedException, AWTException {
		
		ChromeOptions options=new ChromeOptions();
		
		options.addArguments("--disable_Notification--");
		
		ChromeDriver driver=new ChromeDriver(options);
		
		driver.manage().window().maximize();
		Thread.sleep(2000);
		//get url
		driver.get("https://www.easemytrip.com/");
		Thread.sleep(2000);
		
	
		
		    Robot r = new Robot();
		   
	        r.keyPress(KeyEvent.VK_TAB);
	        Thread.sleep(1000);
	        r.keyPress(KeyEvent.VK_TAB);
	        Thread.sleep(1000);
	        r.keyPress(KeyEvent.VK_TAB);
	        Thread.sleep(1000);
	        r.keyPress(KeyEvent.VK_ENTER);
//          r.keyPress(KeyEvent.VK_TAB);
//	        Thread.sleep(1000);
//	        r.keyPress(KeyEvent.VK_ENTER);
//	        
	    driver.findElement(By.id("ddate")).click();
		Thread.sleep(5000);
		
		
		driver.findElement(By.xpath("//li[@id='trd_1_13/01/2025']")).click();
		Thread.sleep(2000);
		
		
		
		driver.findElement(By.xpath("//p[text()='Monday']")).click();
		Thread.sleep(2000);
		
		
		driver.findElement(By.id("img2Nex")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("img2Nex")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("img2Nex")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("img2Nex")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//li[@id='snd_2_06/05/2025']")).click();
		
		Thread.sleep(2000);
//		driver.close();

	}

}
