package pop_up;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FileUpload {

	public static void main(String[] args) throws InterruptedException {


		ChromeDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		driver.get("https://www.ilovepdf.com/word_to_pdf");
		Thread.sleep(2000);
		
		WebElement select_file = driver.findElement(By.xpath("//input[@type='file']"));
		
		select_file.sendKeys("D:\\All Word Files\\AMS Research Paper.doc");
		
		Thread.sleep(2000);
		driver.close();

	}

}
