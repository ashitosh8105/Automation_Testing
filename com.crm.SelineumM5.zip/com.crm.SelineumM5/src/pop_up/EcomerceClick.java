package pop_up;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class EcomerceClick {

	public static void main(String[] args) throws InterruptedException 
	{
		
		String expected_url="https://demowebshop.tricentis.com/news/rss/1";
		ChromeDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		Thread.sleep(0);
		driver.get("https://demowebshop.tricentis.com/");
		
		Actions act=new Actions(driver);
		act.keyDown(Keys.PAGE_DOWN).perform();
		Thread.sleep(2000);
		
		List<WebElement> ecommerce = driver.findElements(By.xpath("//div[@class='column follow-us']/ul/li/a"));
	     for (WebElement web : ecommerce) {
	    	 
	    	 web.click();
	    	 String actual_url = driver.getCurrentUrl();
	    	 if(expected_url.equals(actual_url)) {
	    		//RSS PAGE IS OPEN TO THW SAME DWS PAGE THATS WHY WE GOT BACK TO THE DWS PAGE AND WE MOVE FORWORD
	    		 driver.navigate().back();
	    	 }
	    	 Thread.sleep(2000);
		}
	}

}
