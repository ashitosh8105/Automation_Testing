package pop_up;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class Simple_Alert {

	public static void main(String[] args) throws InterruptedException {
		
		ChromeDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.get(" https://demo.automationtesting.in/Alerts.html");
		
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//a[text()='Alert with OK ']")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//button[@onclick='alertbox()']")).click();
		Thread.sleep(2000);
		
		//handle  simple alert
		Alert alt = driver.switchTo().alert();
		System.out.println(alt.getText());
		alt.accept();
		

	}

}
