package pop_up;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class SimpleAlert {

	public static void main(String[] args) throws InterruptedException {
	
		ChromeDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.get("https://demowebshop.tricentis.com/");
		
		//we use Alter method to handle simple alert
		  //accept(),dismiss(),getalert(),sendkeys()
		
		driver.findElement(By.xpath("//input[@value='Search']")).click();
		Alert alt = driver.switchTo().alert();
		Thread.sleep(2000);
		alt.accept();
		
		  
		
//		Thread.sleep(5000);
//		driver.close();
		

	}

}
