package pop_up;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.Keys;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Handle_Notification_Poupu {

	public static void main(String[] args) throws InterruptedException, AWTException {

        ChromeDriver driver=new ChromeDriver();
        
        driver.manage().window().maximize();
        Thread.sleep(5000);
        driver.get("https://www.easemytrip.com/");
        Thread.sleep(2000);
        
        
        //here we have try to use Action method TAB it not work directely
        //by overcome this we need to use Robot class which is present in AWT package
//        Actions act=new Actions(driver);
//        act.keyDown(Keys.TAB).perform();
      
        Robot r = new Robot();
        r.keyPress(KeyEvent.VK_TAB);
        Thread.sleep(1000);
        r.keyPress(KeyEvent.VK_TAB);
        Thread.sleep(1000);
        r.keyPress(KeyEvent.VK_TAB);
        Thread.sleep(1000);
        r.keyPress(KeyEvent.VK_ENTER);
        r.keyPress(KeyEvent.VK_TAB);
        Thread.sleep(1000);
        r.keyPress(KeyEvent.VK_ENTER);
        
        Thread.sleep(2000);
        driver.close();
        
        

	}

}
