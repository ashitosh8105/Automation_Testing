package pop_up;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Child_Browser {

	public static void main(String[] args) throws InterruptedException {
		
		ChromeDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		driver.get("https://demowebshop.tricentis.com/");
		
		//handle parent page it will give the hexadecimal value
		String parent_handle = driver.getWindowHandle();
		System.out.println(parent_handle);

		Actions act=new Actions(driver);
		act.keyDown(Keys.PAGE_DOWN).perform();//scrolling the page 
		
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[text()='Facebook']")).click();
		
//		driver.findElement(By.xpath("//a[text()='Facebook']")).click();
		
		//handle parent page and child page it will give the hexadecimal value
		Set<String> child = driver.getWindowHandles();
		System.out.println( child);
		child.remove(parent_handle);
		for (String str : child) 
		 {
			driver.switchTo().window(str);
		}
		driver.findElement(By.xpath("//span[text()='Create new account']")).click();
		
		driver.close();
		
	}
}
