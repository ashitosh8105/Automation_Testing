package pop_up;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.decorators.WebDriverDecorator;

public class AvoidNotifications 
{

	public static void main(String[] args) throws InterruptedException {
		
		ChromeOptions options=new ChromeOptions();
		options.addArguments("disable_notification");
		
		ChromeDriver driver=new ChromeDriver(options);
		
		driver.manage().window().maximize();
		
		Thread.sleep(5000);
		driver.get("https://www.easemytrip.com/");
		
		Thread.sleep(2000);
//		driver.close();
		
		

	}

}
