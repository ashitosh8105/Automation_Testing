package pop_up;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Get_Page_Handle {

	public static void main(String[] args) throws InterruptedException {
		
         ChromeDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		driver.get("https://demowebshop.tricentis.com/");

		//handle parent page it will five the headecemal value
		String parent_handle = driver.getWindowHandle();
		System.out.println(parent_handle);
		
		Actions act=new Actions(driver);
		Thread.sleep(1000);
		act.keyDown(Keys.PAGE_DOWN).perform();
		
		driver.findElement(By.xpath("//a[text()='Facebook']")).click();
		Set<String> child = driver.getWindowHandles();
		System.out.println( child);
		
		Thread.sleep(2000);
		driver.close();
		
	}

}
