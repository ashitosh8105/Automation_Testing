package pop_up;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Multiple_Child_Browser {

	public static void main(String[] args) throws InterruptedException 
	{
	  String expected_url = "https://x.com/nopCommerce?mx=2";
	  
      ChromeDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		driver.get("https://demowebshop.tricentis.com/");
		
		//handle parent page it will give the hexadecimal value
		String parent_handle = driver.getWindowHandle();
		System.out.println(parent_handle);
           
		Actions act=new Actions(driver);
		act.keyDown(Keys.PAGE_DOWN).perform();//scrolling the page 
		
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[text()='Facebook']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[text()='Twitter']")).click();
		
		//get handle
       Set<String> childs = driver.getWindowHandles();
       for (String str : childs){
		 
    	   driver.switchTo().window(str);
    	   String actual_url = driver.getCurrentUrl();
    	   if(expected_url.equals(actual_url)) 
    	   {
    		   driver.findElement(By.xpath("//span[text()='Create account']")).click();
    	   }
    	   Thread.sleep(2000);
	}
       
       
	}

}
