package pop_up;

import java.awt.RenderingHints.Key;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class PageHandleAssign {

	public static void main(String[] args) throws InterruptedException {
		
		String expected_title = "Demo Web Shop";
		String expected_Rss_Url = "https://demowebshop.tricentis.com/news/rss/1";
		String expected_fb_url = "https://www.facebook.com/nopCommerce";
		String expected_twit_url = "https://x.com/nopCommerce";
		ChromeDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		
		driver.get("https://demowebshop.tricentis.com/"); 
		Actions act=new Actions(driver);
		act.keyDown(Keys.PAGE_DOWN).perform();
		Thread.sleep(2000);
		
		String parent_handle = driver.getWindowHandle();
		System.out.println(parent_handle);
		
		String actual_title = driver.getTitle();
		
		if(actual_title.equals(expected_title)) 
		{
			System.out.println("Page verified sucessfully");
			
		
			
			List<WebElement> follow_us =driver.findElements(By.xpath("//a[@target='_blank']"));
			
			for (WebElement web : follow_us) 
			{
				web.click();
				 String actual_rss_url = driver.getCurrentUrl();
		    	 if(expected_Rss_Url.equals(actual_rss_url)) {
		    		//RSS PAGE IS OPEN TO THW SAME DWS PAGE THATS WHY WE GO  BACK TO THE DWS PAGE AND WE MOVE FORWORD
		    		 driver.navigate().back();
		    	 }
				Set<String> child = driver.getWindowHandles();
				child.remove(parent_handle);
				for (String str : child) 
				      
					driver.switchTo().window(str);
					String actual_fb_url = driver.getCurrentUrl();
					String actual_twit_url = driver.getCurrentUrl();
					if(expected_fb_url.equals(actual_fb_url)) 
					{
						driver.findElement(By.xpath("//span[text()='Create new account']")).click();
						continue;
					}
				
					else if(expected_twit_url.equals(actual_twit_url))
					{
						System.out.println("Twit page verified");
					}
					else {
						System.out.println("Twit page not verified");
					}

			  }
				
				
			}
			
		else{
			System.out.println("page is not present");
		}
		Thread.sleep(2000);
		driver.close();
	}

}
