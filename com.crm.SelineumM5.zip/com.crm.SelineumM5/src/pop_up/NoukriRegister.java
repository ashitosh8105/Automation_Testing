package pop_up;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class NoukriRegister {

	public static void main(String[] args) throws InterruptedException {
		
	ChromeDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		driver.get("https://www.naukri.com/");
//		Thread.sleep(2000);
		
	    driver.findElement(By.xpath("//a[@id='register_Layer']")).click();

	    WebElement name = driver.findElement(By.xpath("//input[@id='name']"));
	    name.sendKeys("Ashitosh Jagtap");
	    
	    WebElement email = driver.findElement(By.xpath("//input[@id='email']"));
	    email.sendKeys("ashitosh1234@gmail.com");
	    
	    WebElement pass = driver.findElement(By.xpath("//input[@id='password']"));
	    pass.sendKeys("Pass@123");
	    
	    WebElement mob = driver.findElement(By.xpath("//input[@id='mobile']"));
	    mob.sendKeys("9874563212");
	    Thread.sleep(2000);
	    
	    Actions act=new Actions(driver);
	
			Thread.sleep(1000);
			act.keyDown(Keys.PAGE_DOWN).perform();
			act.keyDown(Keys.PAGE_DOWN).perform();
			act.keyDown(Keys.PAGE_DOWN).perform();
			act.keyDown(Keys.PAGE_DOWN).perform();
			act.keyDown(Keys.PAGE_DOWN).perform();
	    
	  driver.findElement(By.xpath("//p[text()='  I have work experience (excluding internships)']")).click();
	  Thread.sleep(2000);
	  
	  driver.findElement(By.xpath("//button[text()='Upload Resume']")).click();
	    Thread.sleep(2000);
	    
	    WebElement select_file = driver.findElement(By.xpath("//button[text()='Upload Resume']"));
	    
	    select_file.sendKeys("C:\\Users\\Ashitosh\\Downloads\\Ashitosh_Jagtap CV.pdf");
//	    driver.close();
	}

}
