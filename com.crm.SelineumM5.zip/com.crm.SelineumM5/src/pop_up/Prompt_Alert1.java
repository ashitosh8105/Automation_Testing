package pop_up;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class Prompt_Alert1 {

	public static void main(String[] args) throws InterruptedException {
	
		
		ChromeDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		driver.get("https://demo.automationtesting.in/Alerts.html");
		Thread.sleep(2000);
		
		
		driver.findElement(By.xpath("//a[text()='Alert with Textbox ']")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//button[@onclick='promptbox()']")).click();
		Thread.sleep(2000);
		
		
		Alert alt = driver.switchTo().alert();
		alt.sendKeys("Ashitosh");
		Thread.sleep(2000);
		System.out.println(alt.getText());
		alt.accept();
		

	}

}
