package pop_up;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class Robot_Class {

	public static void main(String[] args) throws InterruptedException, AWTException {
		 ChromeDriver driver=new ChromeDriver();
	        
	        driver.manage().window().maximize();
	        Thread.sleep(2000);
	        driver.get("https://demowebshop.tricentis.com/");
	        Thread.sleep(5000);
	        
	        Robot r=new Robot();
	        driver.findElement(By.xpath("//input[@id='small-searchterms']")).click();
	        
	        r.keyPress(KeyEvent.VK_A);
	        Thread.sleep(1000);
	        r.keyPress(KeyEvent.VK_S);
	        Thread.sleep(1000);
	        r.keyPress(KeyEvent.VK_H);
	        Thread.sleep(1000);
	        r.keyPress(KeyEvent.VK_U);
	        Thread.sleep(1000);
	       
	        
	        r.keyRelease(KeyEvent.VK_A);
	        Thread.sleep(1000);
	        r.keyRelease(KeyEvent.VK_S);
	        Thread.sleep(1000);
	        r.keyRelease(KeyEvent.VK_H);
	        Thread.sleep(1000);
	        r.keyRelease(KeyEvent.VK_U);
	        Thread.sleep(1000);
	        
	        driver.close();
	        
	        

	}

}
