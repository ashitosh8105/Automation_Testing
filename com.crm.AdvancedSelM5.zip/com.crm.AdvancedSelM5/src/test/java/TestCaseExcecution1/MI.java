package TestCaseExcecution1;

import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
public class MI {
	@Test(groups="functional")
	
	public void mumbaiIndians() {
	
		ChromeDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		//wait condition
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		driver.get("https://www.mumbaiindians.com/");
		driver.quit();
		
	}
}
