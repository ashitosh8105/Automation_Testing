package TestCaseExcecution1;
import java.time.Duration;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class ecommerce{
//smoke testing
	@Test(groups="smoke")
	public void dwsPage() {
		
	ChromeDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		//wait condition
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		driver.get("https://demowebshop.tricentis.com/");
		driver.quit();
	}
	
	@Test(groups="smoke")
	public void flipcart() {
		ChromeDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		//wait condition
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		driver.get("https://www.google.com/");
		driver.quit();
	}
	@Test(groups="smoke")
	public void amazon() {
ChromeDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		//wait condition
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		driver.get("https://www.amazon.in/");
		driver.quit();
	}
}
