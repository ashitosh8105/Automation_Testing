package DataDrivenTesting;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class AssignDataProvider {

	@DataProvider(name="hrmlogin")
	public Object[][] User() throws EncryptedDocumentException, IOException, InterruptedException{
		
		FileInputStream fis=new FileInputStream(".\\src\\test\\resources\\HRMLogin.xlsx");
		Workbook wb = WorkbookFactory.create(fis);
		Sheet sheet = wb.getSheet("HRM");
		
		int row=sheet.getPhysicalNumberOfRows();
		
		int colum=sheet.getRow(0).getPhysicalNumberOfCells();
		Object[][] obj=new Object[row][colum];
		
		for (int i = 0; i < row; i++){
			for (int j = 0; j < colum; j++) {
				
				obj[i][j]=sheet.getRow(i).getCell(j).toString();
				Thread.sleep(2000);
				
			}
			
		}
		return obj;
	}
	
	@Test(dataProvider="hrmlogin")
	public void orangeHRM(String username,String password) throws InterruptedException {
		
		ChromeDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		//waiting time
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div/div[1]/div/div[2]/div[2]/form/div[1]/div/div[2]/input")).sendKeys(username);
		
		driver.findElement(By.xpath("//input[@type='password']")).sendKeys(password);
	
		
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		
		Thread.sleep(5000);
		driver.close();
		
		Thread.sleep(5000);
		
	}
}
