package DataDrivenTesting;

import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.testng.annotations.Test;

import com.crmFileUtility.ReadFromExcel;

public class ReadExcelByFactoryMethod {

	@Test
	public void  main() throws EncryptedDocumentException, IOException, InterruptedException {
		//call ReadFromExcel file from com.crmFileUtility Package from src/main/java folder
		String username1 = ReadFromExcel.getData("Login", 0, 0);
		
		System.out.println(username1);
	}
}
