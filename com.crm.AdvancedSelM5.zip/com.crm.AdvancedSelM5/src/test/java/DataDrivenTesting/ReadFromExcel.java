package DataDrivenTesting;

import java.io.FileInputStream;
import java.io.IOException;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.testng.annotations.Test;

public class ReadFromExcel {

	@Test
	public void login() throws EncryptedDocumentException, IOException, InterruptedException
	{
		FileInputStream fis=new FileInputStream(".\\src\\test\\resources\\DWS_Login.xlsx");
		Workbook wb = WorkbookFactory.create(fis);
		Sheet sheet = wb.getSheet("Login");
		Thread.sleep(2000);
		
		String username1 = sheet.getRow(0).getCell(0).toString();
		Thread.sleep(2000);
		String password1 = sheet.getRow(0).getCell(1).toString();
		Thread.sleep(2000);
		String username2 = sheet.getRow(1).getCell(0).toString();
		Thread.sleep(2000);
		String password2 = sheet.getRow(1).getCell(1).toString();
		System.out.println(username1);
		System.out.println(password1);
		System.out.println(username2);
		System.out.println(password2);
	}
}

