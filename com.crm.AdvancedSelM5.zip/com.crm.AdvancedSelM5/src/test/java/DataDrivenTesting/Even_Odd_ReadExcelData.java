package DataDrivenTesting;

import java.io.FileInputStream;

import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.testng.annotations.Test;

public class Even_Odd_ReadExcelData {

	@Test
	public void assign() throws Exception
	{
		FileInputStream fis=new FileInputStream(".\\src\\test\\resources\\Values.xlsx");
		
		Workbook wb = WorkbookFactory.create(fis);
		
		Sheet sheet = wb.getSheet("Numbers");
		Thread.sleep(2000);
		int row = sheet.getPhysicalNumberOfRows();
		int colom = sheet.getRow(0).getPhysicalNumberOfCells();
		System.out.println(row+" "+colom);
		
		for (int i = 0; i <row; i++) {
			for (int j = 0; j <colom; j++) {
				
				 int value = (int)sheet.getRow(i).getCell(j).getNumericCellValue();

	                // Check if the value is even or odd
	                if(value % 2 == 0){
	                    System.out.println(value+ " is Even Number");
	                }else 
	                {
	                    System.out.println(value+" is Odd Number");
	                }
	                Thread.sleep(2000);
				
			}
			
		}
		
	}
}
