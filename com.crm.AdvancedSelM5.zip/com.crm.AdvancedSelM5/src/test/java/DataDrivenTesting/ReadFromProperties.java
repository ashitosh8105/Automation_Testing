package DataDrivenTesting;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.testng.annotations.Test;

public class ReadFromProperties {

	@Test
	public void data() throws IOException, InterruptedException {
		
		
		Properties prop = new Properties();
		
		//fileInputStream->read the data
		//fileOutputStream->write the data
		
		FileInputStream file= new FileInputStream(".\\src\\test\\resources\\dwsLogin.properties");
		prop.load(file);
		String browser = prop.getProperty("browser");
		
	    Object url = prop.getProperty("url");
	    String username = prop.getProperty("username");
	    String password = prop.getProperty("password");
	    Thread.sleep(2000);
	    System.out.println(browser);
	    Thread.sleep(2000);
	    System.out.println(url);
	    Thread.sleep(2000);
	    System.out.println(username);
	    Thread.sleep(2000);
	    System.out.println(password);
	    Thread.sleep(2000);
	    
	    
	    
	    
		
		
	}
	
}
