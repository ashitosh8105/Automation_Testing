package DataDrivenTesting;

import java.io.FileInputStream;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.testng.annotations.Test;

public class Prime_or_Not_ReadExcelData {
  
    @Test
    public void prime() throws Exception {
        // Load the Excel file
        FileInputStream fis = new FileInputStream(".\\src\\test\\resources\\Values.xlsx");
        Workbook wb = WorkbookFactory.create(fis);
        
            Sheet sheet = wb.getSheet("Number");
               
            // Get the number of rows and columns
            int row = sheet.getPhysicalNumberOfRows();
            int col = sheet.getRow(0).getPhysicalNumberOfCells();
            isPrime(0);
            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    int value = (int) sheet.getRow(i).getCell(j).getNumericCellValue();

                    // Check if the number is prime
                    if (isPrime(value)) {
                        System.out.println(value + " is a Prime Number");
                    } else {
                        System.out.println(value + " is Not a Prime Number");
                    }
                    Thread.sleep(2000);
                }
            }
        }
       
    
    private boolean isPrime(int num) {
        if (num <= 1){
            return false;
        }
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0){
                return false; 
            }
        }
        return true; 
    }
}
