package DataDrivenTesting;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class UsingDataProvider{
   @DataProvider(name="login")
	public Object[][] sender()
    {
		Object[][]obj=new Object[2][2];
		obj[0][0]="admin01@gmail.com";
		obj[0][1]="admin01";
		obj[1][0]="admin01@@gmail.com";
		obj[1][1]="admin01111";
		return obj;
	}
   
   @Test(dataProvider="login")
	public void reciever(String username,String password) throws InterruptedException {
   	//passing the multiple parameter in testNG class
   	      ChromeDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		//wait condition
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(25));
	
		driver.get("https://demowebshop.tricentis.com/");//read url(data) from parametrization.xml file and pass it the value as url
		Thread.sleep(2000);
		driver.findElement(By.className("ico-login")).click();
	
		driver.findElement(By.id("Email")).sendKeys(username);
		
		driver.findElement(By.id("Password")).sendKeys(password);
		
//		driver.findElement(By.id("RememberMe")).click();
		
		driver.findElement(By.cssSelector(".button-1.login-button")).click();
		Thread.sleep(2000);
		driver.close();
		
		Thread.sleep(5000);
		
}}

