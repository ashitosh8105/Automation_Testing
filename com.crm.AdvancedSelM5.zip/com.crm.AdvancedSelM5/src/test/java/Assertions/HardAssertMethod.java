package Assertions;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNull;
import static org.testng.Assert.assertTrue;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class HardAssertMethod {
      //Assertion: Its library/function which is used to verify the validate Expected Result and actual result
	@Test
	public void dws() {
		String container=null;
		String expected_result="https://demowebshop.tricentis.com/";
		ChromeDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		driver.get("https://demowebshop.tricentis.com/");
		
		String actual_result = driver.getCurrentUrl();
		
		assertEquals(expected_result, actual_result,"im not in DWS Page");
		Reporter.log("im in DWS page",true);
		
		
		driver.findElement(By.id("small-searchterms")).sendKeys("iphone18");
		WebElement search_button = driver.findElement(By.xpath("//input[@type='submit']"));
		
		//assertTrue
		assertTrue(search_button.isEnabled(),"search button is not enabled....");
		
		Reporter.log("search button is enabled....");
		search_button.click();
		
		//assertNull
		assertNull(container);
		driver.close();
		
		
	}
}
