package Assertions;

import org.openqa.selenium.chrome.ChromeDriver;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class AssignAssertion {

	@Test
	public void dws1() {
		
		String actual_url="https://demowebshop.tricentis.com/";
		String actual_url1="https://demowebshop.tricentis.com/login";
		String username="admin01@gmail.com";
		String password="admin01";
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		driver.get("https://demowebshop.tricentis.com/");
		
		String expected_url=driver.getCurrentUrl();
		
		assertEquals(actual_url,expected_url,"i am not in homePage");
		Reporter.log("i am in homePage");
		
		driver.findElement(By.className("ico-login")).click();
		String expected_url1=driver.getCurrentUrl();
		
		//assertEquals
		assertEquals(actual_url1,expected_url1,"login element not verified");
		Reporter.log("login element is verified",true);
		
		driver.findElement(By.cssSelector("[id='Email']")).sendKeys(username);
		WebElement emailField=driver.findElement(By.cssSelector("[id='Email']"));
		
		String enteredUsername=emailField.getAttribute("value");
		
		assertEquals(enteredUsername,username,"username does not match the entered value");
		Reporter.log("entered username is verified:"+enteredUsername,true);
		
		
		//This area is mainly used to check the whatever data we have send it to the textField it will check whether it is correct or not.
		driver.findElement(By.xpath("//input[@class='password']")).sendKeys(password);
		
		WebElement passwordField=driver.findElement(By.xpath("//input[@class='password']"));
		
		String enteredPassword=passwordField.getAttribute("value");
		
		assertEquals(password,enteredPassword,"You have entered wrong password");
		
		Reporter.log("You have entered correct password:"+enteredPassword,true);
		
		WebElement login=driver.findElement(By.xpath("//input[@value='Log in']"));
		assertTrue(login.isEnabled(),"login element is not enabled");
		
		Reporter.log("Login element is enabled");
		login.click();
		
		driver.quit();
		
		
	}
}