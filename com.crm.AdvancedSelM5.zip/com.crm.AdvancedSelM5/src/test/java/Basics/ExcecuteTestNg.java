package Basics;

import org.testng.annotations.Test;

public class ExcecuteTestNg {

	@Test
	public void ashu()
	{
		
		System.out.println("Hello Automation");
		m1();
	}
	public void m1() {
		System.out.println("I am a m1()");
	}
	
	@Test
	public void sammed() {
		System.out.println("hello sammed");
	}
	@Test
	public void sam() {
		System.out.println("hello sam");
	}
	@Test
	public void apple() {
		System.out.println("hello newton");
	}
	
	
}
