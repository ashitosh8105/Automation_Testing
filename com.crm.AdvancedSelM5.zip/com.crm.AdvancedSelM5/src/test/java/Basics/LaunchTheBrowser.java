package Basics;

import org.openqa.selenium.chrome.ChromeDriver;

public class LaunchTheBrowser{

	public static void main(String[] args) 
	{
                  
		//pom:Project object Model
		//if error do:go to window which present in taskbar
		    //:click on preferences 
		
		//go to Maven and click on check button 3rd to 8th option
		 
		ChromeDriver driver=new ChromeDriver();
        

		
		

	}

}
