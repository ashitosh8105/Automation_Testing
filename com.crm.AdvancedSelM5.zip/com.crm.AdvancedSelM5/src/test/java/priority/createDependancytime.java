package priority;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
//testNG always start the execution from priority 0 not mattert all the testNG classes are should have in sequencial order
public class createDependancytime {
   //provide time
	@Test(priority=2)
		public void createAccount() throws InterruptedException
		{
		   	//@Test(priority=1,timeOut=2000)
		
			ChromeDriver driver=new ChromeDriver();
			driver.manage().window().maximize();
			driver.get("https://demowebshop.tricentis.com/");
		    driver.close();
		    System.out.println("createAccount");
		    Thread.sleep(2000);
		}
	
	@Test(priority = 0)
	
	public void updateAccount() throws InterruptedException{
		
		ChromeDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.chennaisuperkings.com/");
		driver.close();
		System.out.println("updateAccount");
		Thread.sleep(2000);
	}
	
	@Test(priority=1)
	public void deleteAccount() throws InterruptedException{
		
		ChromeDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.mumbaiindians.com/");
		driver.close();
		System.out.println("deleteAccount");
		Thread.sleep(2000);
	}
	
	}

	


