package TestCaseExecution2;

import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Ktm {

	@Test(groups="functional")
	public void ktmBike() {
		ChromeDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		//wait condition
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		driver.get("https://www.ktmindia.com/");
		driver.quit();
	}
}
