package TestCaseExecution2;

import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class RoyalEnfield {

	@Test(groups="functional")
	public void bullet() {
		
		ChromeDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		//wait condition
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		driver.get("https://www.royalenfield.com/");
		driver.quit();
	}
}
