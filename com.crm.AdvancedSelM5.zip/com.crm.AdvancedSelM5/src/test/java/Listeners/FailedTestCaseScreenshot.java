package Listeners;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import com.crmBaseClass.DwsPageBase;
@Listeners(com.crm.Linteners.FailedTestCase.class)

public class FailedTestCaseScreenshot extends DwsPageBase
{
   @Test
   public void DigitalDownload() throws InterruptedException {
	   
	   driver.findElement(By.xpath("//a[contains(text(),'Digital downloads')]")).click();
	   Thread.sleep(2000);
	   driver.findElement(By.xpath("//input[@value='Add to cart']")).click();
	   
	   driver.findElement(By.className("ico-cart")).click();
	   Thread.sleep(2000);
	   try{
		WebElement album3rd = driver.findElement(By.xpath("(//a[text()='3rd Album'])[2]"));
		assertFalse( album3rd.isDisplayed(),"product is not added");
		Reporter.log("product is added sucessfully",true);
		driver.findElement(By.name("removefromcart")).click();
		driver.findElement(By.name("updatecart")).click();
	} catch (Exception e) {

          Reporter.log("product is present",true);
          assertEquals("m", "n","product is not present");
	}
	   
	   
	   
   }
}
