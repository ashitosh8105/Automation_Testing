package Listeners;

import static org.testng.Assert.assertEquals;


import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
@Listeners(com.crm.Linteners.Sample.class)

public class SampleTestCase {

	@Test
	public void dwsPage(){
		Reporter.log("dws TestCase",true);
		ChromeDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		//wait condition
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		driver.get("https://demowebshop.tricentis.com/");
		driver.quit();
	}
		
		@Test
		public void flipKart() {
			Reporter.log("flipcart TestCase",true);
			ChromeDriver driver=new ChromeDriver();
			
			driver.manage().window().maximize();
			//wait condition
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
			driver.get("https://www.flipkart.com/");
			driver.close();
			assertEquals("mani", "money");
		}
		@Test(dependsOnMethods = "flipKart")
		public void amazon() {
			Reporter.log("amazon TestCase");
			ChromeDriver driver=new ChromeDriver();
			driver.manage().window().maximize();
			//wait condition
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
			driver.get("https://www.amazon.in/");
			driver.quit();
//			assertEquals("mani", "money");
		}
		
	}

