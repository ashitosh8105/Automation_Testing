package TestNG;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.crmBaseClass.DwsPageBase;
import com.crmBaseClass.DwsPageBase;

public class ExecuteWithConfiguration extends DwsPageBase {

	@Test
	public void test1(){
		
		driver.findElement(By.xpath("//input[@id='small-searchterms']")).sendKeys("iphone14");
		driver.findElement(By.cssSelector(".button-1.search-box-button")).click();
	}
	
	@Test
	public void test2() throws InterruptedException {
		
		String rss_url="https://demowebshop.tricentis.com/news/rss/1";
		
		List<WebElement> ecommerce= driver.findElements(By.xpath("//div[@class='column follow-us']/ul/li/a"));
		for(WebElement web:ecommerce){
			String actual_url=driver.getCurrentUrl();
			if(rss_url.equals(actual_url))
			{
				driver.navigate().back();
			}
			
			web.click();
			Thread.sleep(1000);
		}
		
		Thread.sleep(2000);
		
	 }
		
	}

