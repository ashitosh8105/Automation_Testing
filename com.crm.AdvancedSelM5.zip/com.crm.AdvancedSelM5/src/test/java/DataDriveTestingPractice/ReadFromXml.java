package DataDriveTestingPractice;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class ReadFromXml {
	
	@Parameters({"url","username","password"})
	@Test
	public void main(String url,String username,String password) throws InterruptedException {
		
		ChromeDriver driver=new ChromeDriver();
		//maximize the browser
		driver.manage().window().maximize();
		
		//waiting time
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		
	//get url
		driver.get(url);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@name='username']")).sendKeys(username);
		
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys(password);
		
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		
		driver.close();
		
		
		
	}
	
	
	
	

}
