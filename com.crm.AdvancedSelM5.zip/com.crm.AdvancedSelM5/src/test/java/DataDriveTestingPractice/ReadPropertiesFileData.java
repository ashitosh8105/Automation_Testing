package DataDriveTestingPractice;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Properties;

import org.testng.annotations.Test;

public class ReadPropertiesFileData {

	@Test
	public void data() throws FileNotFoundException, InterruptedException {
	Properties prop=new Properties();
	
	FileInputStream file=new FileInputStream(".\\src\\test\\resources\\OrageHRM.properties");
	
	String browser = prop.getProperty("browser");
	
	String url = prop.getProperty("url");
	
	String username = prop.getProperty("username");
	
	String password = prop.getProperty("password");
	
	Thread.sleep(2000);
	System.out.println(browser);
	Thread.sleep(2000);
	System.out.println(url);
	Thread.sleep(2000);
	System.out.println(username);
	Thread.sleep(2000);
	System.out.println(password);
	
	
	
	
	
}
}
