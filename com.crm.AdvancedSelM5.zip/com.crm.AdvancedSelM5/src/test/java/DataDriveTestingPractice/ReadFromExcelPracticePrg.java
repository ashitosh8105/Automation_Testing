package DataDriveTestingPractice;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class ReadFromExcelPracticePrg {

	@Test
	public void readExcel() throws EncryptedDocumentException, IOException, InterruptedException {
		
		FileInputStream fis=new FileInputStream(".\\src\\test\\resources\\usernames.xlsx");
		//create workbookfactory
		
		Workbook wb = WorkbookFactory.create(fis);
		//get Excelsheet name
		
		Sheet sheet = wb.getSheet("sheet1");
		
		int row=sheet.getPhysicalNumberOfRows();
		
		int colum=sheet.getRow(0).getPhysicalNumberOfCells();
		for (int i = 0; i <row; i++) {
			
			for (int j = 0; j < colum; j++) {
				
				String data = sheet.getRow(i).getCell(j).toString();
				System.out.println(data);
				Thread.sleep(1000);
			}
			
		}
		
	}
	
}
