package DataDriveTestingPractice;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DataProviderPractice{

	@DataProvider(name="hrmLogin")
	public Object[][] sender(){
		
		Object[][] obj= new Object[2][2];
		obj[0][0]="Admin";
		obj[0][1]="admin123";
		obj[1][0]="Demo";
		obj[1][1]="demo123";
		return obj;
		
		
	}
	@Test(dataProvider="hrmLogin")
	public void reciver(String username,String password) throws InterruptedException 
	{
		ChromeDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@name='username']")).sendKeys(username);
        Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys(password);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		
		driver.close();
		
		Thread.sleep(2000);
		
	}
}
