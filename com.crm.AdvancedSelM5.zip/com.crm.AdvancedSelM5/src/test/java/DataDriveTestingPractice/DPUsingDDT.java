package DataDriveTestingPractice;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DPUsingDDT {
@DataProvider(name="hrmlogin")

public Object[][]sender() throws EncryptedDocumentException, IOException, InterruptedException{
	
	FileInputStream fis=new FileInputStream(".\\src\\test\\resources\\HRMLogin.xlsx");
	
	//create a workBook
	Workbook wb = WorkbookFactory.create(fis);
	//get sheet
	Sheet sheet = wb.getSheet("HRM");
	
	int row=sheet.getPhysicalNumberOfRows();
	
	int colum=sheet.getRow(0).getPhysicalNumberOfCells();
	Object[][]obj=new Object[row][colum];
	
	for (int i = 0; i < row; i++) {
		
		for (int j = 0; j < colum; j++) {
			
			obj[i][j]= sheet.getRow(i).getCell(j).toString();
			Thread.sleep(2000);
		}
		
	}
	return obj;
}
@Test(dataProvider="hrmlogin")
public void reciver(String username,String password) throws InterruptedException 
{
	ChromeDriver driver=new ChromeDriver();
	
	driver.manage().window().maximize();
	
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
	
	driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
	
	Thread.sleep(1000);
    driver.findElement(By.xpath("//input[@name='username']")).sendKeys(username);
    Thread.sleep(2000);
	driver.findElement(By.xpath("//input[@name='password']")).sendKeys(password);
	Thread.sleep(2000);
	driver.findElement(By.xpath("//button[@type='submit']")).click();
	
	driver.close();
	
	Thread.sleep(2000);
	
}
}

