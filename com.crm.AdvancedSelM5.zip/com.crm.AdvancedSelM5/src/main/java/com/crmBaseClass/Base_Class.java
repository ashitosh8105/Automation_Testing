package com.crmBaseClass;

import org.openqa.selenium.chrome.ChromeDriver;

public class Base_Class {

	public static ChromeDriver driver=null;
	
	public static void preCondition() throws InterruptedException
	{
	  driver=new ChromeDriver();
	  
	  driver.manage().window().maximize();
	  Thread.sleep(2000);
	  driver.get(null);
	 }
	public static void login() {
		
		
	}
	
}
